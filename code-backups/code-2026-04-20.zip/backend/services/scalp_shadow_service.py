"""
ScalpShadowService — Shadow Logging para D1_HIGH / D1_LOW

Colecta observações quando o preço toca as máximas/mínimas da sessão anterior.
Nunca gera trades. Regista outcomes a 5 / 15 / 30 minutos para alimentar o Sprint C.

Colecção MongoDB: scalp_d1_obs
Índices: symbol+zone_type+ts, status+scheduled_resolve_at
"""
from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional

logger = logging.getLogger("scalp_shadow_service")

OUTCOME_WINDOWS_MIN = [5, 15, 30]
DEDUP_WINDOW_MIN    = 30
FADE_SUCCESS_THRESH = 1.0   # múltiplo de ATR para considerar FADE_SUCCESS
BREAK_THRESH        = 1.0   # múltiplo de ATR para considerar BREAKOUT_CONFIRMED


class ScalpShadowService:
    def __init__(self) -> None:
        self._db                              = None
        self._live_data_service               = None
        self._dedup: Dict[str, datetime]      = {}
        self._lock: asyncio.Lock              = asyncio.Lock()

    def set_db(self, db) -> None:
        self._db = db

    def set_live_data_service(self, svc) -> None:
        self._live_data_service = svc

    # ─────────────────────────────────────────────────────────────────────────
    # Escrita de observação
    # ─────────────────────────────────────────────────────────────────────────

    async def log_observation(
        self,
        symbol: str,
        zone_type: str,
        level: float,
        direction: str,
        price: float,
        distance: float,
        context: Dict[str, Any],
        session_label: str = "UNKNOWN",
        regime: str = "UNKNOWN",
        atr: float = 0.0,
    ) -> Optional[str]:
        if self._db is None:
            return None

        dedup_key = f"{symbol}:{zone_type}"
        now       = datetime.now(timezone.utc)

        async with self._lock:
            last_ts = self._dedup.get(dedup_key)
            if last_ts and (now - last_ts).total_seconds() < DEDUP_WINDOW_MIN * 60:
                logger.debug(
                    "[SHADOW] Dedup — %s %s já logado há %.1f min",
                    symbol, zone_type,
                    (now - last_ts).total_seconds() / 60,
                )
                return None
            self._dedup[dedup_key] = now

        obs_id = str(uuid.uuid4())[:16]
        doc = {
            "obs_id":           obs_id,
            "symbol":           symbol,
            "zone_type":        zone_type,
            "direction":        direction,
            "level":            level,
            "price_at_touch":   price,
            "distance_at_touch": distance,
            "atr_at_touch":     round(atr, 4),
            "ts":               now,
            "session_label":    session_label,
            "regime":           regime,
            "expected_outcome": "FADE",
            "context":          context,
            "status":           "OPEN",
            "outcomes": {
                "5min":  {"ts": None, "price": None, "move_pts": None, "verdict": None},
                "15min": {"ts": None, "price": None, "move_pts": None, "verdict": None},
                "30min": {"ts": None, "price": None, "move_pts": None, "verdict": None},
            },
            "final_verdict":    None,
            "max_fade_pts":     None,
            "max_break_pts":    None,
            "resolved_at":      None,
            "scheduled_resolve_at": now + timedelta(minutes=OUTCOME_WINDOWS_MIN[-1] + 1),
        }

        try:
            await self._db.scalp_d1_obs.insert_one(doc)
            logger.info(
                "[SHADOW] Observação logada — %s %s @ %.2f (dist=%.2f pts | atr=%.2f)",
                symbol, zone_type, level, distance, atr,
            )
            return obs_id
        except Exception as exc:
            logger.warning("[SHADOW] Erro ao gravar observação: %s", exc)
            return None

    # ─────────────────────────────────────────────────────────────────────────
    # Resolução de outcomes (chamado periodicamente pelo monitor loop)
    # ─────────────────────────────────────────────────────────────────────────

    async def resolve_pending_outcomes(self, live_prices: Dict[str, float]) -> None:
        if self._db is None:
            return

        now = datetime.now(timezone.utc)

        try:
            cursor = self._db.scalp_d1_obs.find({"status": "OPEN"})
            async for doc in cursor:
                symbol   = doc.get("symbol", "")
                price    = live_prices.get(symbol)
                if price is None:
                    continue

                touch_ts    = doc.get("ts")
                touch_price = doc.get("price_at_touch", 0.0)
                level       = doc.get("level", 0.0)
                direction   = doc.get("direction", "SHORT")
                atr         = doc.get("atr_at_touch") or 1.0
                outcomes    = doc.get("outcomes", {})

                updates: Dict[str, Any] = {}
                all_filled = True

                for win_min in OUTCOME_WINDOWS_MIN:
                    win_key = f"{win_min}min"
                    if outcomes.get(win_key, {}).get("price") is not None:
                        continue
                    if touch_ts and (now - touch_ts).total_seconds() >= win_min * 60:
                        move = round(price - touch_price, 2)
                        if direction == "SHORT":
                            fade_pts  = round(-move, 2)
                        else:
                            fade_pts  = round(move, 2)
                        if fade_pts >= 0:
                            verdict = "FADE"
                        else:
                            verdict = "BREAK"
                        updates[f"outcomes.{win_key}.ts"]       = now
                        updates[f"outcomes.{win_key}.price"]    = price
                        updates[f"outcomes.{win_key}.move_pts"] = move
                        updates[f"outcomes.{win_key}.verdict"]  = verdict
                    else:
                        all_filled = False

                if not updates:
                    continue

                if all_filled:
                    thirty_outcome = outcomes.get("30min", {})
                    thirty_price   = updates.get("outcomes.30min.price") or thirty_outcome.get("price")
                    if thirty_price is not None:
                        move_30 = round(thirty_price - touch_price, 2)
                        if direction == "SHORT":
                            fade_30 = -move_30
                        else:
                            fade_30 = move_30

                        fade_pts_list = [
                            outcomes.get("5min", {}).get("move_pts") or 0,
                            outcomes.get("15min", {}).get("move_pts") or 0,
                        ]
                        if "outcomes.5min.move_pts" in updates:
                            fade_pts_list[0] = (
                                -updates["outcomes.5min.move_pts"] if direction == "SHORT"
                                else updates["outcomes.5min.move_pts"]
                            )
                        if "outcomes.15min.move_pts" in updates:
                            fade_pts_list[1] = (
                                -updates["outcomes.15min.move_pts"] if direction == "SHORT"
                                else updates["outcomes.15min.move_pts"]
                            )
                        fade_pts_list.append(fade_30)

                        max_fade  = round(max((v for v in fade_pts_list if v > 0), default=0.0), 2)
                        max_break = round(abs(min((v for v in fade_pts_list if v < 0), default=0.0)), 2)

                        if fade_30 >= FADE_SUCCESS_THRESH * atr:
                            final_verdict = "FADE_SUCCESS"
                        elif fade_30 <= -BREAK_THRESH * atr:
                            final_verdict = "BREAKOUT_CONFIRMED"
                        else:
                            final_verdict = "INCONCLUSIVE"

                        updates["status"]         = "RESOLVED"
                        updates["resolved_at"]    = now
                        updates["final_verdict"]  = final_verdict
                        updates["max_fade_pts"]   = max_fade
                        updates["max_break_pts"]  = max_break

                        logger.info(
                            "[SHADOW] Resolvido — %s %s @ %.2f → %s (fade30=%.1f pts, max_fade=%.1f, max_break=%.1f)",
                            doc.get("symbol"), doc.get("zone_type"), level,
                            final_verdict, fade_30, max_fade, max_break,
                        )

                await self._db.scalp_d1_obs.update_one(
                    {"_id": doc["_id"]},
                    {"$set": updates},
                )

        except Exception as exc:
            logger.warning("[SHADOW] Erro ao resolver outcomes: %s", exc)

    # ─────────────────────────────────────────────────────────────────────────
    # Stats resumo
    # ─────────────────────────────────────────────────────────────────────────

    async def get_summary(self, symbol: Optional[str] = None, days: int = 30) -> Dict[str, Any]:
        if self._db is None:
            return {"error": "db_not_set"}

        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        query: Dict[str, Any] = {"ts": {"$gte": cutoff}}
        if symbol:
            query["symbol"] = symbol

        total      = await self._db.scalp_d1_obs.count_documents(query)
        resolved   = await self._db.scalp_d1_obs.count_documents({**query, "status": "RESOLVED"})
        open_count = await self._db.scalp_d1_obs.count_documents({**query, "status": "OPEN"})

        by_verdict: Dict[str, int] = {}
        by_zone:    Dict[str, Dict] = {}
        if resolved > 0:
            cursor = self._db.scalp_d1_obs.find(
                {**query, "status": "RESOLVED"},
                {"zone_type": 1, "final_verdict": 1, "max_fade_pts": 1,
                 "max_break_pts": 1, "symbol": 1},
            )
            async for doc in cursor:
                v  = doc.get("final_verdict", "UNKNOWN")
                zt = doc.get("zone_type", "UNKNOWN")
                by_verdict[v] = by_verdict.get(v, 0) + 1

                if zt not in by_zone:
                    by_zone[zt] = {"count": 0, "fade_success": 0, "breakout": 0,
                                   "inconclusive": 0, "avg_fade_pts": [], "avg_break_pts": []}
                by_zone[zt]["count"] += 1
                if v == "FADE_SUCCESS":
                    by_zone[zt]["fade_success"] += 1
                    if doc.get("max_fade_pts") is not None:
                        by_zone[zt]["avg_fade_pts"].append(doc["max_fade_pts"])
                elif v == "BREAKOUT_CONFIRMED":
                    by_zone[zt]["breakout"] += 1
                    if doc.get("max_break_pts") is not None:
                        by_zone[zt]["avg_break_pts"].append(doc["max_break_pts"])
                else:
                    by_zone[zt]["inconclusive"] += 1

        for zt in by_zone:
            fp = by_zone[zt]["avg_fade_pts"]
            bp = by_zone[zt]["avg_break_pts"]
            by_zone[zt]["avg_fade_pts"]  = round(sum(fp) / len(fp), 2) if fp else None
            by_zone[zt]["avg_break_pts"] = round(sum(bp) / len(bp), 2) if bp else None
            n = by_zone[zt]["count"]
            by_zone[zt]["fade_rate"] = round(by_zone[zt]["fade_success"] / n, 3) if n else None

        latest = []
        cursor2 = self._db.scalp_d1_obs.find(
            query, {"obs_id": 1, "symbol": 1, "zone_type": 1, "level": 1,
                    "price_at_touch": 1, "ts": 1, "final_verdict": 1,
                    "status": 1, "session_label": 1}
        ).sort("ts", -1).limit(20)
        async for doc in cursor2:
            doc.pop("_id", None)
            latest.append(doc)

        return {
            "total":       total,
            "resolved":    resolved,
            "open":        open_count,
            "days":        days,
            "by_verdict":  by_verdict,
            "by_zone":     by_zone,
            "latest":      latest,
        }


scalp_shadow_service = ScalpShadowService()

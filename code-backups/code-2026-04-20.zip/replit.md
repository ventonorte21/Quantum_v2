# Quantum Trading Scalp

Full-stack quantitative trading system for automated micro futures (MES/MNQ). Bi-mode Scalp Engine (FLOW + ZONES) with DataBento Live tick feed, 1–3 minute holds, bracket OCO execution via SignalStack/Tradovate.

**V3 legacy system fully removed.** Event loop belongs entirely to the Scalp pipeline.

**Modo de operação (2026-04-20):** Sistema opera exclusivamente em modo **ZONES** para ambos os símbolos. `auto_trade_flow=False` globalmente; `auto_trade_flow_mes=False` e `auto_trade_zones_mes=True` explícitos. Sinais de modo FLOW que apareçam com `gate_outcome=MODE_BLOCKED` no signal_log são ruído de auditoria — excluídos automaticamente do cálculo de hyp outcomes (`scalp_hyp_outcomes.py`, exclusion list). `warmup_minutes_overnight` reduzido de 2 para 1 min (evidência de custo: +8.7pts perdidos por 6 segundos, 2026-04-20).

**Critical bug fixed (2026-04-13):** G-2 quality filter in `scalp_auto_trader.py` was blocking ALL trades. Root cause: Python 3.12 `str(ScalpSignalQuality.MODERATE)` returns `"ScalpSignalQuality.MODERATE"` (not `"MODERATE"`), causing `_QUALITY_RANK` dict lookup to return -1 (below WEAK). Fix: `_normalize_quality()` extracts `.value` from enum directly. Auto-start on restart now works via `auto_trade: True` in `scalp_config`.

**Mode isolation fixes (2026-04-19):** `handleStartAT` and `handleSaveConfig` in `ScalpDashboard.jsx` now correctly isolate mode auto-trade flags. When starting the loop from a mode tab (ZONES/FLOW), the other mode is explicitly disabled; when saving config from a tab, the other mode's flag is preserved from the stored config. Additionally: if the loop is already running and the user clicks "Ativar" in the other mode's tab, the button is now enabled (disabled only when this specific mode is already active, not just when the loop is running) and clicking it patches only that mode's flag without restarting the loop.

**EOD hyp_outcomes auto-trigger (2026-04-19):** `_compute_hyp_outcomes_eod()` added to `ScalpAutoTrader`. Called automatically as a background task on every EOD transition (trading window closes). Triggers `compute_all_pending(days_back=1)` so that hypothetical outcomes (TP_HIT/SL_HIT/EOD) for the day's blocked signals are computed without requiring a manual POST to `/report/compute-hyp`.

**Sprint A implementado (2026-04-19):**
- **A1 — Backup com retenção e chunking:** `github_backup_service.py` reescrito com `RETENTION_DAYS=30`, `MAX_FILE_BYTES=20MB`, chunking automático por `CHUNK_DOCS=5000`, prune de pastas antigas via GitHub API, e documentação do drill de restore.
- **A2 — strategy_version + config_id:** `LOGIC_FIELDS` whitelist + `_compute_config_id()` (SHA-8) em `scalp_auto_trader.py`. `_current_config_id`/`_current_strategy_version` mantidos em memória e actualizados em `_get_config_cached`. `config_id`/`strategy_version` adicionados ao trade_doc e ao signal_log. `config_audit_log` escrito em `save_scalp_config` com campos lógicos modificados.
- **A3 — Dedup bucketed counters:** `_write_dedup_bucket()` com upsert `$inc` em `scalp_dedup_counters` (bucket por minuto, `logged_count` + `suppressed_count`, `zone_type="NA"` para gates sem zona). Índice único + TTL 30d criados no `start()`. Chamado a partir de `_log_signal_event` em ambos os paths (logado/suprimido).
- **A4 — Hypothesis expiry schema + notifier:** `_check_hypothesis_expiry()` lê `hypothesis_registry` do config, conta sessões distintas em `scalp_snapshots` e eventos em `scalp_signal_log` desde `activated_at`, e escreve em `hypothesis_review_queue` quando critérios atingidos (sem duplicar se já existe pending). Chamado no EOD transition. Índice por `hypothesis_id` + `status` criado no `start()`.
- **A5 — MAE/MFE com lifetime fields:** `lifetime_best_price`/`lifetime_worst_price` adicionados ao trade_doc (nunca resetados pelo trailing ratchet). Actualizados no monitoring loop (os campos `best_price`/`worst_price` continuam a ser resetados pelo trailing). `mae_pts`/`mfe_pts` calculados em `_close_trade` com fórmula direccional `max(0,...)` e persistidos no trade fechado.

**Sprint B-infra implementado (2026-04-19) — B1a/B1b/B1c:**
- **B1a — Timestamps de latência:** quatro campos adicionados ao trade_doc para rastreio de latência end-to-end: `signal_ts` (timestamp do ScalpSignal gerado pelo engine, também adicionado ao signal_log doc); `order_sent_ts` (capturado imediatamente antes de `client.post(webhook_url)` — mede latência engine→PMT); `first_market_tick_ts` + `first_market_tick_price` (primeiro tick DataBento recebido após o envio da ordem, com preço nesse tick — proxy de mercado, NÃO fill confirmation do Tradovate; permite calcular slippage teórico = first_market_tick_price − entry_price). Persistidos assincronamente via `update_one` em `scalp_trades`.
- **B1b — GET /scalp/dedup-stats:** endpoint de auditoria de deduplicação. Agrega `scalp_dedup_counters` por (gate × symbol) com janela temporal configurável (default 24h, param `hours`). Retorna `logged_count`, `suppressed_count`, `suppression_rate = suppressed/(logged+suppressed)`, ordenado por `suppressed_count desc`. Summary global com taxa de supressão agregada. Filtros opcionais: `gate`, `symbol`.
- **B1c — GET /scalp/config-audit:** endpoint de histórico de configuração. Lista últimas N entradas de `config_audit_log` (default 50, max 500), ordenadas por `ts desc`. Filtro `logic_changed_only=true` mostra apenas saves que alteraram campos do `LOGIC_FIELDS` whitelist. Permite correlacionar mudanças de comportamento da estratégia com performance do journal via `config_id`.

**Shadow Logging D1_HIGH / D1_LOW (2026-04-20):**
- **ZoneType:** `D1_HIGH_FADE_SELL` + `D1_LOW_FADE_BUY` adicionados em `scalp_zones.py`. Detectados em `evaluate_zones()` com tolerância `max(0.50×ATR, TICK_SIZE×4)` → MNQ 3.11pts (12 ticks), MES 1.0pt (4 ticks). Retornados em `shadow_zones` (nunca como `active_zone` → sem execução).
- **`scalp_shadow_service.py`:** serviço singleton com `log_observation()` (dedup 30min) / `resolve_pending_outcomes()` (5/15/30min: FADE_SUCCESS/BREAKOUT_CONFIRMED/INCONCLUSIVE) / `get_summary()`.
- **MongoDB:** colecção `scalp_d1_obs`. Endpoint `GET /api/scalp/shadow-obs`.
- **Comportamento esperado:** 0 observações durante OVERNIGHT (distância ao D1 HIGH/LOW >> tolerância). Shadow activa exclusivamente em RTH quando preço toca D1 HIGH/LOW dentro da tolerância.

**Audit de Pipeline + Fixes (2026-04-20):**
- **Backfill outcome:** 191 trades pré-Sprint A sem campo `outcome` actualizados via pipeline `$cond` (pnl_pts>0→WIN, <0→LOSS, =0→SCRATCH) no startup de `server.py`. Idempotente.
- **Dedup bug fix:** `_write_dedup_bucket` em `scalp_auto_trader.py` tinha dois bugs: (1) `asyncio.ensure_future()` silencioso substituído por `await` directo; (2) `$setOnInsert` incluía `logged_count`/`suppressed_count` em conflito com `$inc` no mesmo campo na mesma operação MongoDB → `WriteError` swallowed a DEBUG. Removidos do `$setOnInsert` (MongoDB inicializa campos indefinidos a 0 antes do `$inc`).
- **by_d30 label:** `None` → `"N/A"` no breakdown `n3_context.by_d30` do `/daily-funnel` (trades OVERNIGHT sem barras RTH para calcular deslocamento 30m).
- **`GET /api/scalp/pipeline-health`:** endpoint de auditoria contínua — verifica missing_outcome, loop snaps 35min, signal_log 24h/7d, dedup write_active, d1_shadow total, WR por sessão e zona.
- **Tolerância D1 shadow corrigida:** floor de `4×1.25=5.0pts` para MNQ substituído por `4×TICK_SIZE=1.0pt`, permitindo `0.50×ATR=3.11pts` (era 9.33pts → -67%).

**ensure_future → create_task/await EOD tasks (2026-04-20):**
- **Diagnóstico:** Após converter as 10 chamadas `_log_signal_event` para `await`, identificados 4 `asyncio.ensure_future()` adicionais no ficheiro:
  - Linha 382 (`_check_sprint_gates` startup) → `create_task()` — background, não pode bloquear
  - Linha 412 (`_log_circuit_breaker_event`) → `create_task()` — background, não pode bloquear
  - Linha 687 (`_compute_hyp_outcomes_eod`) → `create_task()` — background EOD, não pode bloquear
  - Linha 689 (`_check_hypothesis_expiry`) → `create_task()` — background EOD, não pode bloquear
  - Linha 691 (`_check_sprint_gates` EOD) → `create_task()` — background EOD, não pode bloquear
  - Linha 890 (`scalp_shadow_log.insert_one`) → `await` — escrita de dados críticos (shadow outcomes), ocorre apenas 1×/evento
  - Linha 1507 (`scalp_trades.update_one first_market_tick`) → `await` — escrita de dados críticos (latência/slippage), ocorre apenas 1×/trade
- **Resultado:** `asyncio.ensure_future` = 0 ocorrências em `scalp_auto_trader.py`. Python 3.7+ reporta excepções de `create_task()` via event loop em vez de engoli-las silenciosamente.

**Hypo tracker — fixes de integridade (2026-04-20):**
- **P2+P5 — entry_reached:** `compute_hyp_outcome` agora verifica se o preço tocou `entry ± 1 tick` antes de declarar TP_HIT/SL_HIT. Se o preço nunca regressou ao nível de entrada, `hyp_outcome="ENTRY_NEVER_REACHED"` e `hyp_pnl_pts=None`. Campo `hyp_entry_reached: bool | None` adicionado ao documento signal_log. Crítico para D30_BLOCKED onde preço pode estar 20+ pts da zona no momento do bloco.
- **P4 — Deduplicação 10 min:** `compute_all_pending` agora detecta sinais com mesmo `symbol|zone_type|direction` a menos de `DEDUP_WINDOW_SECONDS=600s`. O segundo sinal e seguintes dentro da janela recebem `hyp_outcome="DUPLICATE"` e `hyp_pnl_pts=None`. O primeiro sinal da sequência processa normalmente. Retorno do batch inclui campo `"duplicates": N`. Evita inflar N com re-emissões do mesmo setup.
- **Novos campos no signal_log (glossário):** `hyp_entry_reached` (bool — price tocou entry ±1tick antes de TP/SL/EOD); `hyp_outcome` agora inclui `"ENTRY_NEVER_REACHED"` e `"DUPLICATE"` além de TP_HIT/SL_HIT/EOD/NO_DATA.

**Integridade de dados + Logging persistente (2026-04-20):**
- **`asyncio.ensure_future()` → `await` no signal_log:** 10 chamadas a `_log_signal_event` em `scalp_auto_trader.py` convertidas de fire-and-forget para `await` directo. Elimina risco de perda silenciosa de eventos em carga elevada (RTH). Validado: sintaxe Python OK, todos os 10 pontos convertidos.
- **`GET /api/scalp/signal-log`:** endpoint de browsing directo da colecção `scalp_signal_log`. Filtros: `symbol`, `gate`, `session`, `zone_type`, `regime`, `hours` (default 24h), `limit` (max 1000), `hyp_only`, `pending_hyp`, `include_executed`. Retorna eventos individuais com score_breakdown, OFI, CVD, hyp_outcome, param_snapshot. Corrigi o 500 que ocorria porque a rota não existia e caía no handler de ficheiros estáticos do frontend.
- **Logging persistente em ficheiro:** `server.py` agora configura dois handlers adicionais em `/home/runner/workspace/logs/` (git-ignorado): (1) `RotatingFileHandler` → `backend.log` (20 MB, 7 backups = 140 MB max); (2) `TimedRotatingFileHandler` → `backend_daily.log` (rotação à meia-noite UTC, 30 dias de retenção). Logs sobrevivem a restarts do workflow; o `/tmp/logs/` continua a existir para o painel do Replit.
- **hyp_outcome computation verificada:** trigger manual `POST /report/compute-hyp?days=1` processou 4 sinais bloqueados do dia 2026-04-20 (G7_BLOCKED=1, G2_BLOCKED=3) com 0 erros. Resultados: TP_HIT=1, SL_HIT=2, EOD=1. O sinal G7_BLOCKED MNQ SIGMA2_FADE_BUY 01:33 (H2 da análise matinal) confirmado TP_HIT +8.7 pts — em linha com o benchmark hipotético de +7.5 estimado.

---

## Backlog — Sprints Pendentes

### Sprint B-comportamento — Inteligência Relacional
**Gate: N≥30 sessões de mercado reais acumuladas em `scalp_signal_log` / `scalp_trades`.**
Enquanto o gate não for atingido, estas tarefas não devem ser iniciadas — os dados seriam insuficientes para calibração estatisticamente válida.

Itens planeados:
- **BC-1 — Session-level pattern mining:** win-rate por zone_type, horário (slot RTH), e config_id; usando os campos de latência (B1a) e MAE/MFE (A5) já presentes no trade_doc.
- **BC-2 — EWM smoothing de gate thresholds:** ajuste automático dos thresholds de G-2 (quality gate) e G-3/G-4 (daily limits) com base em média ponderada exponencial da performance recente por símbolo.
- **BC-3 — Track B relational intelligence:** queries relacionais cruzando `scalp_signal_log` (sinais bloqueados com hyp_outcome=TP_HIT) com `scalp_trades` (entradas reais) para detectar padrões de over-blocking por gate específico.
- **BC-4 — POST /scalp/comportamento/activate:** endpoint que verifica o gate N≥30, computa os parâmetros iniciais e escreve no `scalp_config` com flag `comportamento_active=true`.
- **BC-5 — Hipótese: absorção OFI inválida em BEARISH_FLOW + CVD FALLING (registada 2026-04-20):**
  - **Observação:** Trade #2 (MNQ BUY SIGMA2_FADE_BUY 01:56, LOSS −3.5 pts) executado com 3 sinais confluentes de risco bearish: regime BEARISH_FLOW, CVD FALLING, ofi_fast=−0.2388. O sistema não bloqueou porque `abs(ofi_fast) ≥ OFI_FAST_MIN` numa fade zone é tratado como absorção (+2.0 pts), superando as penalidades Fix E (−0.5) e Fix 5 (−0.3). Score resultante: 3.3 → passou threshold MODERATE.
  - **Hipótese:** Quando `regime=BEARISH_FLOW AND cvd_trend=FALLING AND ofi_fast*sign<0 AND zone.direction=LONG`, o OFI negativo reflecte tendência em acção (não absorção). Neste contexto, a interpretação de absorção deve ser suprimida — tratando `_ofi_directional = ofi_fast * sign` (como zona de momentum) em vez de `abs(ofi_fast)`.
  - **Score estimado se corrigido:** 3.3 − 2.0 (absorção removida) = 1.3 → G2_BLOCKED.
  - **Contra-exemplo observado:** Hipotético H2 (MNQ BUY 01:37, G7_BLOCKED, bench +7.5) também tinha BEARISH_FLOW mas atingiu TARGET. **Mesma condição, resultados opostos** — logo a hipótese precisa de N≥30 para validação estatística antes de qualquer alteração ao scoring.
  - **Variável de controlo chave:** entry price relativo à zona (01:37 entrou 14.5 pts mais profundo na -3σ que 01:56). A precisão da entrada pode ser mais determinante que o regime.
  - **Acção em Sprint B:** calcular WR de SIGMA2_FADE_BUY quando `BEARISH_FLOW + CVD_FALLING + ofi_fast<0` vs restantes contextos. Se WR < 40% com N≥10 ocorrências, implementar supressão da absorção neste contexto.
  - **hypothesis_id:** `H001_ABSORPTION_BEARISH_FLOW` — monitorizado por A4 (`hypothesis_registry` no config).

- **BC-6 — Hipótese: D30 excessivamente restritivo em OVERNIGHT/Globex (registada 2026-04-20):**
  - **Observação:** Sessão Globex 20-Abr bloqueou 544/1.549 snapshots (35.1%) via gate D30 — o maior gargalo da sessão, antes de qualquer análise de zona. Os 3 sinais que chegaram a N2 tinham scores 3.3–4.8 (acima do threshold STRONG=4.0), confirmando que setups de alta qualidade existem mas são eliminados antes de serem avaliados.
  - **Hipótese:** O threshold de displacement D30 foi calibrado em RTH onde o deslocamento 30-min é estruturalmente mais alto (maior volatilidade, range mais amplo). Em OVERNIGHT, o drift é mais lento e o deslocamento acumulado em 30 minutos é estruturalmente menor. Usar o mesmo threshold produz uma taxa de bloqueio sistematicamente mais alta em Globex.
  - **Contra-hipótese:** O D30 alto em OVERNIGHT pode ser protecção legítima contra fakeouts em baixo volume. Confirmar com WR dos trades que passam D30 em OVERNIGHT vs RTH antes de reduzir o threshold.
  - **Dados necessários para validação:**
    1. `d30_block_rate` por sessão (OVERNIGHT vs RTH_*) ao longo de N≥30 sessões
    2. Distribuição do `displacement_30m` nos snapshots bloqueados (percentis 25/50/75 por sessão)
    3. WR/PnL dos trades OVERNIGHT após D30 clearance vs RTH
  - **Acção em Sprint B:** se `d30_block_rate_overnight > 30%` em ≥20 sessões consecutivas, calibrar thresholds D30 separados por sessão. Se WR OVERNIGHT ≥ WR RTH, confirmar hipótese e reduzir `displacement_required_overnight`.
  - **hypothesis_id:** `H002_D30_GLOBEX_RESTRICTIVE` — monitorizado por A4 (`hypothesis_registry` no config).

- **BC-7 — Hipótese: SL/TP/Trailing não diferenciado por sessão OVERNIGHT vs RTH (registada 2026-04-20):**
  - **Observação:** Config actual usa `be_ticks_mnq=4` (1.0 pts) e `be_ticks_mes=3` (0.75 pts) como trigger de breakeven E distância do ratchet trailing, sem distinção por sessão. ATR OVERNIGHT tipicamente 4–5 pts MNQ → be_pts representa **22% ATR**. ATR RTH tipicamente 8–10 pts → be_pts representa **10–12% ATR**. O trailing é proporcionalmente 2× mais apertado em OVERNIGHT. Evidência: Trade 20-Abr MNQ SELL 01:34 (OVERNIGHT): MFE=5.25 pts, saiu a +2.93 pts (56% capturado). MES BUY 22:59: MFE=1.0 pts, saiu a +0.20 pts (20% capturado). Ambos por STOP_HIT após ratchet activado.
  - **Mecanismo do ratchet:** `trailing_active=True` quando MFE ≥ `be_pts`. Stop segue: `new_sl = best_price − be_pts` (BUY) / `best_price + be_pts` (SELL). Loop a cada 5 segundos — tick-level extremes capturados no MFE/MAE mas ratchet actualiza em intervalos de 5s, criando lag entre MFE registado e stop real.
  - **Hipótese:** `be_pts` baseado em percentagem de ATR (ex: 20% ATR) calibraria o trailing proporcionalmente ao regime de volatilidade da sessão, capturando mais dos movimentos OVERNIGHT sem aumentar risco absoluto.
  - **Contra-hipótese:** Trail mais largo em OVERNIGHT pode transformar WINs em LOSSes se o mercado reverter completamente após o pico (baixo volume = reversões rápidas).
  - **Dados necessários para validação:**
    1. `mfe_capture_pct = pnl_pts / mfe_pts` por sessão (OVERNIGHT vs RTH) — mínimo N≥10 trades WIN
    2. ATR médio no momento de entrada por sessão (`atr_m1` já gravado nos trades)
    3. `be_pts_as_pct_atr = be_pts / atr_m1` por trade — calcular distribuição
    4. Taxa de stop-out por trailing antes de TP: OVERNIGHT vs RTH
  - **Acção em Sprint B:** se `mfe_capture_pct_overnight < 50%` com N≥10 trades WIN OVERNIGHT, implementar `be_pts_overnight = max(be_ticks_floor, atr_m1 * 0.20)` como campo adicional no config. RTH mantém be_ticks fixo actual.
  - **hypothesis_id:** `H003_SL_TP_TRAILING_SESSION_DIFF` — monitorizado por A4 (`hypothesis_registry` no config).

- **BC-8 — Hipótese: EMA_PULLBACK bloqueada pelo D30 quando direcção alinhada (registada 2026-04-20):**
  - **Root cause confirmado:** Engine faz `return signal` na linha 1306 de `scalp_engine.py` ao detectar `D30_BLOCKED`, **antes** de calcular ATR e chamar `_build_ema_pullback_zones`. Consequência: `atr_m1=0` em 100% dos snaps D30_BLOCKED, e `EMA_PULLBACK` nunca gerou um sinal em 30 dias (0 ocorrências no `scalp_signal_log`).
  - **Evidência (20-Abr):** Rejeição EMA21 5M de 26,800→26,600 (200pts). Durante todo o período (14:30–15:45 UTC): 240/265 snaps D30_BLOCKED, `disp_30m` entre −57 e −158 pts, `atr_m1=0` em todos os bloqueados. Nenhum sinal EMA_PULLBACK gerado.
  - **Problema conceptual:** O D30 foi desenhado para bloquear **fades contra-trend** (SIGMA2, GAMMA). Uma `EMA_PULLBACK_SELL` com `disp_30m < 0` é **trend-following** (a favor do D30), não um fade — o D30 está a bloquear um setup que confirmaria a sua própria leitura.
  - **Fix proposto:** Calcular ATR e EMA zones *antes* do `return` do D30; permitir `EMA_PULLBACK_SELL` quando `disp_30m < −threshold` e `EMA_PULLBACK_BUY` quando `disp_30m > +threshold` — apenas quando a direcção da zona alinha com o contexto D30. SIGMA2/GAMMA continuam bloqueadas pelo D30.
  - **Fix de observabilidade IMPLEMENTADO (2026-04-20):** `scalp_engine.py` linha 1307–1347 — quando D30 é BLOCKED, o engine agora executa `evaluate_zones()` com `_atr_for_d30` (ATR já calculado) antes de fazer `return`. Popula `signal.zone_type_str`, `signal.active_zone`, `signal.zone_score_breakdown`. O auto_trader (linha 952) loga o sinal em `signal_log` com `gate_outcome=D30_BLOCKED` se `zone_type_str` for não vazio. `compute_all_pending` já processa D30_BLOCKED (não está na exclusion list). Sem impacto na execução — D30 continua a bloquear todos os trades; apenas o logging foi activado.
  - **Gate observabilidade:** ✅ COMPLETO
  - **Gate implementar execução:** N≥10 EMA_PULLBACK hipotéticos WIN com direcção alinhada ao D30 (todos zone_types D30_BLOCKED também fornecerão dados).
  - **hypothesis_id:** `H004_EMA_PULLBACK_D30_ALIGNED` — registada em `hypothesis_registry` no config.

- **BC-9 — Hipótese: GAMMA_CALL_WALL_SELL com ABSORPTION_SEL bloqueia setups estruturalmente fortes (registada 2026-04-20):**
  - **Observação:** Dois sinais MES OVERNIGHT `GAMMA_CALL_WALL_SELL` bloqueados por G2 com score N3 de 4.5 e 4.8 (acima do threshold STRONG=4.0) porque a qualidade S2=MODERATE. Ambos tinham `regime=ABSORPTION_SEL, confiança=10.0` (máximo), `ofi_fast<-0.70`. Outcomes hipotéticos: 1×TP_HIT (+3.0pts) e 1×SL_HIT (-1.6pts).
  - **Factor discriminante:** `ofi_slow=-0.157` (SL_HIT) vs `ofi_slow=-0.435` (TP_HIT). Threshold candidato: `ofi_slow<-0.30` separa o sinal de qualidade superior.
  - **Acção em Sprint B:** Se WR≥60% com N≥8 ocorrências, adicionar `GAMMA_CALL_WALL_SELL` à `zone_quality_allow_moderate`, condicionado a `ofi_fast<-0.70 AND absorption_conf≥10`.
  - **hypothesis_id:** `H005_GAMMA_ABSORPTION_QUALITY_UPGRADE`

- **H001 — evidência #1 registada 2026-04-20:** Trade MNQ BUY SIGMA2_FADE_BUY 01:56 (LOSS −3.5pts) confirmou mecanismo de forma directa. `BEARISH_FLOW + CVD_FALLING + ofi_fast=-0.24` interpretado como absorção (+2.0pts bónus), score resultante 3.3. Sem o bónus: 1.3 → G2_BLOCKED esperado. `evidence_count=1`, `review_after_occurrences=10`.

Como monitorar: consultar `GET /scalp/dedup-stats` para acompanhar volume de sessões e `GET /api/scalp/signal-log?limit=1` para verificar a data do primeiro sinal registado.

---

### Sprint C — Walk-Forward Calibration
**Gate: Sprint B-comportamento completo + mínimo de 50 trades fechados na janela de calibração.**
Recalibra SL/TP/BE e zone score thresholds periodicamente com base em dados reais, sem intervenção manual.

Itens planeados:
- **SC-1 — Walk-forward runner** (`backend/services/scalp_walk_forward.py`): janela deslizante sobre `scalp_trades` fechados, grid search sobre candidatos SL/TP, selecção por melhor Sharpe ajustado.
- **SC-2 — Staging de candidatos:** resultados escritos em `scalp_calibration_candidates` com metadados (janela, n_trades, sharpe, config_id_baseline) — revisão humana obrigatória antes de promoção.
- **SC-3 — POST /scalp/walk-forward/run:** disparo manual de uma corrida de calibração.
- **SC-4 — POST /scalp/walk-forward/promote/{candidate_id}:** promove um candidato aprovado para config live; regista em `config_audit_log` com `logic_changed=true`.
- **SC-5 — Trigger semanal automático:** integrado no `ScalpScheduler`, corre todo domingo EOD se o gate de 50 trades for atingido.

---

## Glossário de Campos — Colecções MongoDB

> Referência rápida para evitar erros de nome de campo em queries e diagnósticos.
> Campos críticos que já causaram confusão estão marcados com ⚠️.
> **Última auditoria de produção: 2026-04-20** — todos os campos verificados contra documentos reais.

---

### `scalp_snapshots` — snapshot do engine a cada 30s

| Campo | Tipo | Notas |
|---|---|---|
| `recorded_at` ⚠️ | datetime | Timestamp principal — **NÃO é `ts`** |
| `session_label` ⚠️ | str | Sessão — **NÃO é `session`** — valores: `OVERNIGHT`, `RTH_OPEN`, `RTH_MID`, `RTH_CLOSE` |
| `symbol` | str | `MNQ` ou `MES` |
| `scalp_status` | str | `NO_ZONE`, `NO_SIGNAL`, `ACTIVE_SIGNAL`, `D30_BLOCKED`, `D30_RISK`, `WARMING_UP` |
| `block_gate` | str | Gate específico que bloqueou: `NO_ZONE`, `D30_RANGE`, `ZONE_ENTRY`, `ZONE_OFI_FAST`, `ZONE_CONF_LOW`, `NO_SIGNAL` |
| `last_price` | float | Preço no momento do snapshot |
| `s1_regime` | str | Regime do detector S1 |
| `s1_direction` | str | `LONG` ou `SHORT` |
| `s2_quality` | str | `STRONG`, `MODERATE`, `WEAK`, `NO_TRADE` |
| `zone_score` | float | Score total da zona activa (-1.0 se sem zona) |
| `zone_quality` | str | `STRONG`, `MODERATE`, `WEAK`, `NO_TRADE` |
| `mode` | str | `ZONES` ou `FLOW` |
| `indicators.ofi_fast` ⚠️ | float | OFI fast — **NÃO é `ofi_fast_raw`** (esse é do signal_log) |
| `indicators.ofi_slow` | float | OFI slow |
| `indicators.cvd` | float | CVD cumulativo |
| `indicators.cvd_trend` | str | `RISING`, `FALLING`, `FLAT` |
| `indicators.atr_m1` | float | ATR de 1 minuto |
| `indicators.d30_state` ⚠️ | str | `OK`, `RISK`, `BLOCKED`, `None` — para filtrar D30 usar **`indicators.d30_state`** |
| `indicators.disp_30m` | float | Deslocamento 30min em pts — chave para H002 |
| `indicators.session_minutes` | float | Minutos desde abertura de sessão RTH |
| `indicators.vwap` | float | VWAP da sessão |
| `indicators.absorption_flag` | bool | Absorção detectada |
| `indicators.absorption_side` | str | `BUYER`, `SELLER`, `NONE` |
| `indicators.speed_ratio` | float | Tape speed ratio |
| `indicators.feed_connected` | bool | Feed DataBento activo |
| `levels` | dict | Níveis de mercado: `vwap`, `poc`, `vah`, `val`, `d1_vah`, `d1_val`, `d1_poc`, `sigma2_upper/lower`, `vwap_upper/lower_1/2/3`, `onh`, `onl`, `rth_open_price` |
| `zones` | dict | Resultado completo de `evaluate_zones()`: `day_regime`, `active_zone`, `quality`, `nearby` (list de zonas próximas), `score_breakdown` |
| `data_quality` | dict | Fontes de dados: `atr_source`, `vp_d1_source`, `vp_session_source`, `vwap_source` |
| `macro_context` | dict | Contexto macro: `gamma_call_wall`, `gamma_put_wall`, `gamma_regime`, `gamma_reliable` |

**Query tipo:**
```python
# Contar D30_BLOCKED nas últimas 24h
col.count_documents({"_id": {"$gte": ObjectId.from_datetime(since)}, "indicators.d30_state": "BLOCKED"})
# Funil por status (usar recorded_at via ObjectId.from_datetime para performance)
col.find({"_id": {"$gte": ObjectId.from_datetime(since)}, "symbol": "MNQ"},
         {"recorded_at":1, "scalp_status":1, "block_gate":1, "session_label":1})
```

---

### `scalp_signal_log` — eventos de sinal (N2+)

| Campo | Tipo | Notas |
|---|---|---|
| `ts` ⚠️ | datetime | Timestamp do gate (pós-avaliação) — **NÃO é `recorded_at`** |
| `signal_ts` | str ISO | Quando o engine gerou o sinal (pré-gates) — idêntico a `ts` para EXECUTED |
| `session` ⚠️ | str | Sessão — **NÃO é `session_label`** — valores: `OVERNIGHT`, `RTH_OPEN`, `RTH_MID`, `RTH_CLOSE` |
| `symbol` | str | `MNQ` ou `MES` |
| `paper` | bool | `True` = paper trade, `False` = live |
| `zone_type` | str | `SIGMA2_FADE_BUY/SELL`, `GAMMA_CALL_WALL_SELL`, `EMA_PULLBACK_BUY/SELL`, `SESSION_VAH/VAL_FADE`, `D1_VAH/VAL_FADE_*`, `GAMMA_PUT_WALL_BUY` |
| `zone_level` | float | Nível de preço da zona (entry target) |
| `zone_score` | float | Score total da zona |
| `zone_score_breakdown` ⚠️ | dict | Detalhe do score — chaves: `base_score`, `ofi_slow_penalty`, `tape_speed_modifier`, `late_session_penalty`, `confluence_boost`, `gamma_modifier`, `rth_bias_modifier`, `base_flow_gated`, `delta_quality_capped`, `total_score` |
| `gate_outcome` | str | `EXECUTED`, `G2_BLOCKED`, `G7_BLOCKED`, `D30_BLOCKED`, `MODE_BLOCKED`, `FA_SHADOW` |
| `gate_reason` | str | Descrição textual do motivo de bloqueio |
| `g2_sub_reasons` | list | Sub-razões do G2 (lista de strings: e.g. `late_session=-0.50`) |
| `s2_block_reasons` | list | Razões do bloco S2 |
| `ema_block_reasons` | list | Razões específicas do bloco EMA |
| `gamma_block_reasons` | list | Razões específicas do bloco GAMMA |
| `fix_a_shadow_zones` | list | Zonas FIX-A em shadow (não executadas) |
| `s3_action` | str | `buy` ou `sell` |
| `s3_entry_price` | float | Preço de entrada proposto pelo S3 |
| `s3_sl_price` | float | SL proposto pelo S3 |
| `s3_tp_price` | float | TP proposto pelo S3 |
| `ofi_fast_raw` ⚠️ | float | OFI fast — **NÃO é `ofi_fast`** (esse é no snapshot e no trade) |
| `ofi_slow_raw` | float | OFI slow raw |
| `cvd_trend` | str | `RISING`, `FALLING`, `FLAT` |
| `s1_regime` ⚠️ | str | Regime S1 — **formato com prefixo**: `ScalpRegime.BULLISH_FLOW` (≠ trades onde é `BULLISH_FLOW`) |
| `s1_confidence` | float | Confiança do detector S1 (0.9=instável, 4.0+=estável) |
| `s2_quality` ⚠️ | str | Qualidade — **formato com prefixo**: `ScalpSignalQuality.STRONG` (≠ trades) |
| `d30_state` | str | `OK`, `RISK`, `BLOCKED`, `None` — top-level (≠ `indicators.d30_state` nos snapshots) |
| `disp_30m` | float | Deslocamento 30min em pts — `None` se não disponível |
| `vwap_zone` | str | Posição relativa ao VWAP: `ABOVE_3SD`, `BETWEEN_1SD_2SD_BULL`, `BETWEEN_VWAP_1SD_BULL`, etc. |
| `regime_bias` | str | Bias de regime: `BULLISH`, `BEARISH`, `NEUTRAL` |
| `regime_cvd_conf` | str | Confirmação CVD do regime: `CONFIRMED`, `NEUTRAL`, `AGAINST` |
| `price_vs_rth_open` | str | Posição vs open RTH: `ABOVE`, `BELOW`, `NEUTRAL`, `None` |
| `rth_open_price` | float | Preço de abertura RTH — `None` em OVERNIGHT |
| `signal_id` | str | Hash MD5 do sinal — liga ao trade (`trade.signal_id`) |
| `trade_id` | str | UUID do trade executado (apenas `gate_outcome=EXECUTED`) |
| `config_id` | str | SHA-8 dos LOGIC_FIELDS activos no momento |
| `strategy_version` | str | Versão da estratégia (ex: `"1.0.0"`) |
| `param_snapshot` | dict | Parâmetros activos: `min_quality_eff`, `session`, `zones_score_moderate_thresh`, `zones_score_strong_thresh`, `zone_min_score_overrides`, `zone_quality_allow_moderate` |
| `hyp_computed` | bool | `True` quando outcome hipotético calculado (apenas em sinais BLOQUEADOS) |
| `hyp_outcome` | str | `TP_HIT`, `SL_HIT`, `EOD`, `ENTRY_NEVER_REACHED`, `DUPLICATE`, `NO_DATA` — `None` em EXECUTED |
| `hyp_pnl_pts` | float \| None | PnL hipotético em pts — `None` se `ENTRY_NEVER_REACHED` ou `DUPLICATE` |
| `hyp_entry_reached` ⚠️ | bool \| None | `True` se preço tocou entry ± 1 tick antes do TP/SL — **chave de integridade P2+P5** |
| `hyp_exit_price` | float \| None | Preço de saída hipotético |
| `hyp_exit_at` | datetime \| None | Timestamp da saída hipotética |
| `hyp_computed_at` | datetime | Quando o cálculo foi executado |

**Notas de integridade hyp:**
- `hyp_*` só preenchido em sinais com `gate_outcome ≠ EXECUTED` e `zone_type` preenchido
- `ENTRY_NEVER_REACHED` = sinal D30_BLOCKED onde preço nunca voltou à zona (PnL inválido)
- `DUPLICATE` = mesmo `symbol|zone_type|direction` em < 10 min (não conta como amostra independente)
- Para análise estatística válida: filtrar `hyp_entry_reached=True AND hyp_outcome IN ["TP_HIT","SL_HIT","EOD"]`

**Query tipo:**
```python
# Sinais bloqueados genuínos para análise hipotética
col.find({"ts": {"$gte": since}, "hyp_computed": True,
          "hyp_entry_reached": True, "hyp_outcome": {"$ne": "DUPLICATE"}})
```

---

### `scalp_trades` — trades executados

| Campo | Tipo | Notas |
|---|---|---|
| `created_at` ⚠️ | str ISO | Timestamp de abertura — **é string ISO** (usar `{"$gte": since.isoformat()}`) |
| `closed_at` | str ISO | Timestamp de fecho |
| `session_label` ⚠️ | str | Sessão — **NÃO é `session`** — `OVERNIGHT`, `RTH_OPEN`, `RTH_MID`, `RTH_CLOSE` |
| `session_minutes` | float | Minutos de sessão no momento da entrada |
| `id` | str UUID | ID do trade (campo `id`, não `_id`) |
| `symbol` | str | `MNQ` ou `MES` |
| `action` | str | `buy` ou `sell` |
| `outcome` | str | `WIN`, `LOSS`, `SCRATCH` |
| `pnl_pts` | float | PnL em pontos |
| `pnl_pts_weighted` | float | PnL × lot_fraction (ajustado por sizing) |
| `pnl_usd` | float | PnL em USD |
| `mae_pts` ⚠️ | float | Max Adverse Excursion — **None em trades pré-Sprint A (antes 2026-04-19)** |
| `mfe_pts` ⚠️ | float | Max Favorable Excursion — **None em trades pré-Sprint A** |
| `lifetime_best_price` ⚠️ | float | Melhor preço **nunca resetado** pelo trailing ratchet (≠ `best_price`) |
| `lifetime_worst_price` ⚠️ | float | Pior preço **nunca resetado** pelo trailing ratchet (≠ `worst_price`) |
| `best_price` | float | Melhor preço desde último reset do ratchet (muda com trailing) |
| `worst_price` | float | Pior preço desde último reset do ratchet |
| `atr_m1` | float | ATR 1min no momento de entrada |
| `ofi_fast` ⚠️ | float | OFI fast — **NÃO é `ofi_fast_raw`** (esse é no signal_log) |
| `ofi_slow` | float | OFI slow |
| `cvd` | float | CVD no momento de entrada |
| `cvd_trend` | str | Tendência CVD na entrada |
| `s1_regime` ⚠️ | str | Regime S1 — **formato plano**: `BULLISH_FLOW` (≠ signal_log onde tem prefixo `ScalpRegime.`) |
| `s1_confidence` | float | Confiança do detector S1 |
| `s2_quality` ⚠️ | str | Qualidade — **formato plano**: `STRONG` (≠ signal_log onde tem prefixo `ScalpSignalQuality.`) |
| `zone_type` | str | Tipo de zona |
| `zone_score` | float | Score da zona |
| `score_breakdown` | dict | Detalhe do score (9 sub-keys) |
| `vwap_zone` | str | Posição relativa ao VWAP na entrada |
| `d30_state` | str | Estado D30 na entrada (`OK`, `BLOCKED`, `None`) |
| `disp_30m` | float | Deslocamento 30min na entrada (pts) |
| `entry_price` | float | Preço de entrada |
| `stop_loss_price` | float | SL (valor actual — pode ter sido movido pelo trailing) |
| `take_profit_price` | float | TP |
| `breakeven_pts` | float | Threshold de activação do trailing ratchet |
| `trailing_active` | bool | Se o trailing ratchet activou durante o trade |
| `exit_price` | float | Preço de saída |
| `exit_reason` | str | `STOP_HIT`, `TP_HIT`, `EOD_FLATTEN`, `MANUAL`, `BLACKOUT_FLATTEN` |
| `duration_sec` | float | Duração em segundos |
| `signal_ts` | str ISO | Timestamp de geração do sinal pelo engine (latência engine) |
| `order_sent_ts` | str ISO | Timestamp de envio do webhook (latência engine→PMT) |
| `first_market_tick_ts` | str ISO | Primeiro tick DataBento após envio (proxy de fill) |
| `first_market_tick_price` | float | Preço no primeiro tick após envio (slippage teórico = entry − first_tick) |
| `entry_mechanism` | str | `DIRECT` (standard) |
| `fill_type` | str | `live_pickmytrade`, `paper_simulated` |
| `signalstack_ok` | bool \| None | `True` se webhook retornou 200 (apenas live) |
| `param_snapshot` | dict | Parâmetros activos no momento da entrada |
| `config_id` | str | SHA-8 dos LOGIC_FIELDS |
| `signal_id` | str | Liga ao signal_log correspondente (`signal_log.signal_id`) |
| `strategy_version` | str | Versão da estratégia |
| `paper` | bool | `True` = paper trade |
| `lot_fraction` | float | Fracção do lote (1.0 = tamanho completo) |
| `absorption_flag` | bool | Absorção detectada no momento da entrada |
| `absorption_side` | str | `BUYER`, `SELLER`, `NONE` |

**Cálculos derivados (AutoTune / H003):**
```python
mfe_capture_pct  = trade["pnl_pts"] / trade["mfe_pts"]          # % do MFE capturado
slippage_pts     = abs(trade["first_market_tick_price"] - trade["entry_price"])
be_pts_as_pct_atr = trade["breakeven_pts"] / trade["atr_m1"]    # H003
```

**Query tipo:**
```python
# Trades live fechados das últimas 24h
col.find({"created_at": {"$gte": since.isoformat()}, "paper": False, "state": "CLOSED"})
```

---

### `scalp_config` — configuração activa

| Campo | Notas |
|---|---|
| `id` | Sempre `"default"` — usar `{"id": "default"}` como filtro |
| `be_ticks_mnq` / `be_ticks_mes` | Ticks de breakeven (trigger + distância ratchet trailing) |
| `sl_ticks_mnq` / `sl_ticks_mes` | SL em ticks (fallback/mínimo — SL real é zone-based via ATR) |
| `tp_ticks_mnq` / `tp_ticks_mes` | TP em ticks (fallback — TP real é zone-based via ATR) |
| `atr_stop_multiplier` | Multiplicador ATR para SL real |
| `atr_target_multiplier` | Multiplicador ATR para TP real |
| `warmup_minutes` | Warm-up RTH_OPEN em session_minutes |
| `warmup_minutes_overnight` | Warm-up OVERNIGHT em uptime do AutoTrader — **reduzido para 1 min em 2026-04-20** (era 2) |
| `auto_trade_flow` | `False` — FLOW desactivado globalmente |
| `auto_trade_flow_mes` | `False` — FLOW desactivado explicitamente para MES |
| `auto_trade_zones_mes` | `True` — ZONES activo para MES |
| `min_quality_to_execute` | Qualidade mínima global: `STRONG` ou `MODERATE` |
| `min_quality_rth_mnq` / `min_quality_rth_mes` | Qualidade mínima por sessão RTH e símbolo |
| `min_quality_overnight_mnq` / `min_quality_overnight_mes` | Qualidade mínima OVERNIGHT por símbolo |
| `zones_score_moderate_thresh` | Score mínimo para MODERATE (default 2.5) |
| `zones_score_strong_thresh` | Score mínimo para STRONG (default 4.0) |
| `zone_min_score_overrides` | Dict por zone_type com score mínimo diferente |
| `zone_quality_allow_moderate` | Lista de zone_types que aceitam MODERATE mesmo com config STRONG |
| `r1_moderate_rth_mid_block` | Bool — bloqueia MODERATE em RTH_MID |
| `r2_bearish_rth_mid_close_block` | Bool — bloqueia em regime BEARISH em RTH_MID close |
| `d30_thr_blocked_mult` | float — multiplicador ATR para threshold BLOCKED (default 1.5) — `blocked_thr = max(floor, mult × ATR)` |
| `d30_thr_risk_mult` | float — multiplicador ATR para threshold RISK (default 0.75) — `risk_thr = max(floor, mult × ATR)` |
| `d30_thr_blocked_floor_pts` | float — piso mínimo do threshold BLOCKED em pts (default 20.0) — garante comportamento original em baixa vol |
| `d30_thr_risk_floor_pts` | float — piso mínimo do threshold RISK em pts (default 10.0) |
| `hypothesis_registry` | Array de hipóteses H001–H004 — cada dict com `hypothesis_id`, `activated_at`, `criteria`, `status` |

---

### Armadilhas frequentes

| Erro | Correcto |
|---|---|
| `snapshots.ts` | `snapshots.recorded_at` |
| `snapshots.session` | `snapshots.session_label` |
| `snapshots.ofi_fast` (top-level) | `snapshots.indicators.ofi_fast` |
| `snapshots.d30_state` (top-level) | `snapshots.indicators.d30_state` |
| `snapshots.zones` como lista | `snapshots.zones` é **dict** com chaves `day_regime`, `active_zone`, `nearby` (lista), etc. |
| `signal_log.ofi_fast` | `signal_log.ofi_fast_raw` |
| `signal_log.s1_regime == "BULLISH_FLOW"` | `signal_log.s1_regime == "ScalpRegime.BULLISH_FLOW"` (prefixo de enum) |
| `signal_log.s2_quality == "STRONG"` | `signal_log.s2_quality == "ScalpSignalQuality.STRONG"` (prefixo de enum) |
| `trades.ts` | `trades.created_at` (string ISO — não datetime) |
| `trades.session` | `trades.session_label` |
| `trades.ofi_fast_raw` | `trades.ofi_fast` |
| `trades.best_price` para MFE | `trades.lifetime_best_price` (nunca resetado pelo ratchet) |
| `config._id` como filtro | `config.id == "default"` |
| hyp stats sem filtrar ENTRY_NEVER_REACHED | Filtrar `hyp_entry_reached=True` para análise válida |
| `snapshots.zones.active_params.d30_threshold` | Campo renomeado em 2026-04-20 — usar `d30_thr_blocked` e `d30_thr_risk` (snapshots anteriores a esta data têm `d30_threshold: 20.0`) |

---

### Colecções MongoDB — Mapa Completo

| Colecção | Docs (2026-04-20) | Propósito | TTL / Retenção |
|---|---|---|---|
| `scalp_snapshots` | 50 738 | Estado do engine a cada 30s — AutoTune e hipóteses | Sem TTL (arquivo permanente) |
| `scalp_signal_log` | 39 | Eventos de sinal N2+ (executados + bloqueados) — hyp tracker | Sem TTL |
| `scalp_trades` | 195 | Trades abertos e fechados — journal e MAE/MFE | Sem TTL |
| `scalp_config` | 1 | Configuração activa (`id="default"`) — lida a cada 30s pelo AutoTrader | Sem TTL |
| `scalp_dedup_counters` | 5 | Buckets por minuto de (gate × symbol) — `logged_count + suppressed_count` | TTL 30d (índice TTL) |
| `scalp_d1_obs` | 0 | Observações shadow D1_HIGH/D1_LOW — dados de treino para H005 | Sem TTL |
| `scalp_shadow_log` | 0 | Log de shadow zones FIX-A — custo de oportunidade por FA_SHADOW | Sem TTL |
| `hypothesis_review_queue` | 0 | Fila de revisão quando H001–H004 atingem critério de avaliação (N sessões) | Sem TTL |
| `config_audit_log` | 3 | Histórico de saves de `scalp_config` — cada save com diff de LOGIC_FIELDS | Sem TTL |
| `scalp_trader_state` | 2 | Persistência do AutoTrader entre restarts: cooldown, G3/G4 counters, daily PnL | Upsert (sem acumulação) |
| `feed_health_log` | 40 795 | DQS DataBento a cada 15s por símbolo | Sem TTL (compactar manualmente se necessário) |
| `pb_state_log` | 112 | Estados do Track B (Pullback Observer): TOUCH/RETURN/TIMEOUT/BROKEN | Sem TTL |
| `scalp_tune_history` | 1 | Histórico de corridas walk-forward — candidatos e métricas | Sem TTL |
| `scalp_tune_schedule` / `scalp_combined_schedule` | 1/1 | Agenda do AutoTune D1/D2 | Upsert |
| `news_calendar_monthly` | 1 | Calendário económico mensal — eventos para G-6 blackout | Refresh mensal |

**Nota:** `scalp_combined_history` (11 docs) regista corridas do Combined D1×D2 analysis (suggestions de params + score histórico).

---

### Constantes e TTLs de referência

> Valores hardcoded no código — mudar aqui requer deploy. Comparar com os config fields do `scalp_config` que são runtime.

| Constante | Valor | Ficheiro | Notas |
|---|---|---|---|
| `ATR_MIN_FALLBACK['MNQ']` | `5.0` pts | `scalp_engine.py:55` | Usado quando barras M1 insuficientes |
| `ATR_MIN_FALLBACK['MES']` | `2.0` pts | `scalp_engine.py:55` | — |
| `ATR_CACHE_TTL` | `60.0` s | `scalp_engine.py:58` | ATR recalculado max 1×/min |
| Engine result cache TTL | `2.0` s | `scalp_engine.py:1079` (docstring) | Partilhado entre auto_trader + snapshot_service + HTTP |
| `_CONFIG_CACHE_TTL` | `30.0` s | `scalp_auto_trader.py:149` | Config re-lido do MongoDB max 1×/30s |
| `ZONE_COOLDOWN_SECS` | `180.0` s | `scalp_zones.py:105` | Cooldown por zona após execução (3 min wall-clock) |
| `EMA_WARMUP_BARS` | `39` barras M1 | `scalp_zones.py:113` | EMA34 + 5 buffer — ~39 min mínimos de sessão |
| `EMA_COOLDOWN_SECS` | `180.0` s | `scalp_zones.py:122` | Cooldown de coordenada EMA após trade |
| `EMA_PRICE_COOLDOWN_ATR` | `2.0 × ATR` | `scalp_zones.py:123` | Re-entrada bloqueada se nova EMA21 < 2×ATR da anterior |
| `OFI_SLOW_BLOCK_FADE` | `0.55` | `scalp_zones.py:541` | Threshold OFI slow para fade zones (tolerante) |
| `OFI_SLOW_BLOCK_MOMENTUM` | `0.35` | `scalp_zones.py:542` | Threshold para momentum/pullback (exigente) |
| `BASE_FLOW_GATE` | `1.2` | `scalp_zones.py:655` | Score mínimo de fluxo base antes de modificadores estruturais |
| `_QUALITY_RANK` | `{WEAK:0, MODERATE:1, STRONG:2}` | `scalp_auto_trader.py:146` | Ranking G-2; `.value` extraído por `_normalize_quality()` |
| G-7 warmup RTH_OPEN | `warmup_minutes` (config, default `15`) | `scalp_auto_trader.py:1022` | Em `session_minutes` |
| G-7 warmup OVERNIGHT | `warmup_minutes_overnight` (config, default `2`) | `scalp_auto_trader.py:1037` | Em minutos de uptime do AutoTrader |
| `DEDUP_WINDOW_SECONDS` | `600` s | `scalp_hyp_outcomes.py:45` | Janela 10 min — sinal duplicate no hyp tracker |
| Pre-flight price guard | `12%` desvio | `scalp_auto_trader.py` | Bloqueia ordem se SL/TP > 12% do live price |
| `SCALP_MIN_WARMUP_BARS` | `39` barras | `scalp_engine.py` | Mínimo de barras M1 para ATR e ZONES ativas |

**Como propagar uma mudança de constante:** editar o ficheiro, apagar `.pyc` em `backend/services/__pycache__/`, reiniciar workflow `Backend API`.

---

### Enums de referência

#### `ScalpRegime` — valores do detector S1

| Valor | Contexto | Trigger |
|---|---|---|
| `BULLISH_FLOW` | FLOW | OFI > limiar + CVD rising |
| `BEARISH_FLOW` | FLOW | OFI < −limiar + CVD falling |
| `ABSORPTION_BUY` | FLOW | Absorção detectada do lado comprador |
| `ABSORPTION_SEL` | FLOW | Absorção detectada do lado vendedor |
| `MOMENTUM_BULL` | CANDLE | Candle bullish forte + preço acima VWAP |
| `MOMENTUM_BEAR` | CANDLE | Candle bearish forte + preço abaixo VWAP |
| `REVERSAL_BULL` | CANDLE | Pullback em VWAP com rejeição bearish |
| `REVERSAL_BEAR` | CANDLE | Pullback em VWAP com rejeição bullish |
| `NEUTRAL` | ambos | Sem sinal direcional claro |
| `NO_DATA` | ambos | Barras M1 insuficientes |

**Atenção:** em `scalp_signal_log.s1_regime` aparece com prefixo `"ScalpRegime.BULLISH_FLOW"`. Em `scalp_trades.s1_regime` aparece plano `"BULLISH_FLOW"`.

#### `ScalpSignalQuality` — valores G-2

| Valor | `_QUALITY_RANK` | Critério |
|---|---|---|
| `STRONG` | 2 | S2 passou todos os filtros + confiança alta |
| `MODERATE` | 1 | S2 passou com reservas |
| `WEAK` | 0 | S2 insuficiente |
| `NO_TRADE` | — | S1 sem direcção ou S2 bloqueado |

#### `block_gate` — valores no snapshot (N1 engine-level)

`NO_ZONE` · `D30_RANGE` · `ZONE_ENTRY` · `ZONE_OFI_FAST` · `ZONE_OFI_SLOW` · `ZONE_TAPE_DRY` · `ZONE_CONF_LOW` · `ZONE_SCORE_LOW` · `ZONE_SCORE_MIN` · `ZONE_CONF_MIN` · `GAMMA_SUPPRESSED` · `NO_SIGNAL`

#### `gate_outcome` — valores no signal_log (N2 auto_trader-level)

`EXECUTED` · `G2_BLOCKED` · `G5_BLOCKED` · `G7_BLOCKED` · `G8_BLOCKED` · `D30_BLOCKED` · `MODE_BLOCKED` · `FA_SHADOW` · `TRADING_WINDOW_BLOCKED`

---

## Architecture

- **Frontend**: React (CRA + CRACO) on port 5000 (`frontend/`)
- **Backend**: FastAPI (Python) on port 8000 (`backend/server.py`)
- **Database (dev)**: MongoDB local on port 27017 — database name: `quantum_trading`
- **Database (prod)**: MongoDB Atlas M0 (`quantumscalp.xj16qml.mongodb.net`) — secret `MONGO_URL_ATLAS`; `start_production.sh` auto-selects Atlas when the secret is set
- **Data feed**: DataBento Live (`MNQ.v.0`, `MES.v.0` — continuous front month)
- **Order execution**: SignalStack → Tradovate webhook (bracket OCO)

---

## Workflows

1. **MongoDB** — `mkdir -p /home/runner/mongodb-data && exec mongod --dbpath /home/runner/mongodb-data --port 27017 --bind_ip 127.0.0.1`
2. **Backend API** — `bash start_backend.sh` (waits for MongoDB, then starts uvicorn on port 8000)
3. **Start application** — `cd frontend && PORT=5000 yarn start` (webview on port 5000)

---

## Environment Variables

| Variable | Required | Purpose |
|---|---|---|
| `DATABENTO_API_KEY` | ✅ Yes | Real-time tick data (MNQ/MES) |
| `DASHBOARD_PASSCODE` | ✅ Yes | UI authentication |
| `MONGO_URL` | auto | `mongodb://localhost:27017` |
| `DB_NAME` | auto | `quantum_trading` |
| `REACT_APP_BACKEND_URL` | auto | empty — uses webpack proxy |

Frontend proxies `/api` and `/ws` to `http://localhost:8000` via `frontend/craco.config.js`.

---

## Scalp Engine Architecture (S1 → S2 → S3)

### S1 — Entry Signal (FLOW / ZONES)
- **FLOW mode**: OFI imbalance + delta + tape speed
- **ZONES**: Delta zonal levels (support/resistance from CVD)
- RTH/Globex session gates + SQS (Signal Quality Score) gate
- Outputs `ScalpSignal` with direction, confidence, entry params

### S2 — Confirmation
- Macro context validation (VIX term structure, GEX)
- Feed health DQS gate (≥0.70 required)
- Regime filter (no counter-trend in strong regime)

### S3 — Execution
- Bracket OCO via SignalStack webhook (1–3 min target hold)
- ScalpAutoTrader manages paper/live toggle, position sizing
- `MNQ=$2.00/pt | MES=$5.00/pt | tick_size=0.25`

### Flatten automático
- **EOD flatten** (`eod_flatten_enabled`): detecta transição window-close → chama `flatten_all_trades("EOD_FLATTEN")`.
- **Blackout flatten**: detecta transição `_was_in_blackout=False → True` com posições abertas → chama `flatten_all_trades("BLACKOUT_FLATTEN")`. Trading retoma automaticamente quando o blackout termina.
- **Sequência de flatten para live**: (1) `cancel_all` por símbolo ao Tradovate via SignalStack (cancela SL/TP bracket e ordens órfãs); (2) `close` por símbolo a mercado (apenas se qty > 0); (3) fecha estado interno (`_close_trade(skip_broker=True)`) sem duplicar chamadas ao broker.
- **Close individual** (SL/TP, manual): envia apenas `action_type: "close"` — broker OCO cancela bracket automaticamente. Sem `cancel_all`.

---

## Funil de Gates — G-1 a G-8

O AutoTrader aplica os gates em sequência. O primeiro a bloquear termina o ciclo; o sinal é logado em `scalp_signal_log` com o `gate_outcome` correspondente.

```
tick DataBento (5s)
  └─► engine.evaluate(symbol)          ← result cache 2s TTL
        └─► S1 + S2 + S3 + D30 (engine-level)
              ↓ ScalpSignal
  ─────────────── AUTO TRADER GATES ───────────────
  G-1  Janela de trading (horário + rth_only)      → TRADING_WINDOW_BLOCKED (não logado)
  G-5a News Blackout (G-6 no código = "G-5")       → não logado
  G-3/G-4 Circuit Breaker / max_daily_trades       → não logado (apenas conta em stats)
  D30  Displacement 30min > threshold ATR-dinâmico → D30_BLOCKED  (logado se zone_type ≠ "")
  MODE MODE não activo para este zone_type         → MODE_BLOCKED (logado)
  FA   Fix-A shadow (SIGMA2 em RTH_OPEN)           → FA_SHADOW    (logado)
  G-5b Max contratos simultâneos (após sizing)     → G5_BLOCKED   (logado)
  G-7b Cooldown por symbol + direcção (Lever A)    → não logado (apenas aguarda)
  G-7  Warm-up sessão (RTH_OPEN / OVERNIGHT)       → G7_BLOCKED   (logado)
  G-8  Daily bias filter (VWAP zone + action)      → G8_BLOCKED   (logado)
  G-2  Qualidade mínima (sessão-aware, por símbolo)→ G2_BLOCKED   (logado)
  ─────────────────────────────────────────────────
  EXECUTADO                                        → EXECUTED      (logado)
```

### Parâmetros de cada gate

| Gate | Config key | Default | Notas |
|---|---|---|---|
| G-1 | `rth_only`, `trading_hours_*` | `True` | Período: 09:30–16:15 ET Seg–Sex (ou manual window) |
| G-3 | `max_daily_loss_usd`, `max_consecutive_losses` | 150 USD / 3 | Reset automático a cada dia ET |
| G-4 | `max_daily_trades` | 5 | Reset automático a cada dia ET |
| G-5a | `news_blackout_minutes_before/after` | 15/5 | Baseado em `news_calendar_monthly` |
| G-5b | `max_total_contracts` | 2 | Partilhado MNQ + MES |
| G-6 | — | — | Alias de G-5a no código (ver comentário linha 491 scalp_auto_trader.py) |
| G-7 | `warmup_minutes` (RTH) / `warmup_minutes_overnight` | 15 / 2 | Session_minutes vs uptime do AutoTrader |
| G-7b | `cooldown_minutes` por sym+dir | 5 | Lever A: evita re-entrada imediata mesma direcção |
| G-8 | `vwap_bias_filter_enabled` | True | Suprime BUY quando `vwap_zone=BELOW_3SD`, SELL quando `ABOVE_3SD` |
| G-2 | `min_quality_to_execute`, `min_quality_rth_*`, `min_quality_overnight_*` | STRONG | Sessão-aware + excepcão `zone_quality_allow_moderate` |
| D30 | `d30_thr_blocked_mult/floor` / `d30_thr_risk_mult/floor` | 1.5/20.0 / 0.75/10.0 | ATR-dinâmico; threshold = max(floor, mult × ATR) |

---

## Fluxo de Dados — Tick → Trade

```
DataBento Live (MNQ.v.0 / MES.v.0)
    │  add_trade() a cada tick
    ▼
live_data_service.py — SymbolBuffer
    │  ofi_fast / ofi_slow / cvd / speed_ratio / tick_buffer / period_range
    ▼
scalp_engine.evaluate(symbol)           [result cache 2s, ATR cache 60s]
    │
    ├─ S1: evaluate_s1_flow() / evaluate_s1_candle()   → ScalpRegime + confidence
    ├─ S2: evaluate_s2_flow()                          → ScalpSignalQuality + block_reasons
    ├─ D30: disp_30m vs ATR-dynamic threshold           → d30_state: OK/RISK/BLOCKED
    ├─ S3: compute_s3_params_flow() + populate_signal_levels() → entry/sl/tp
    └─ ZONES: evaluate_zones(symbol, s3_params)        → active_zone + score_breakdown
         │  [popula signal.zone_type_str e signal.active_zone]
         ▼
    ScalpSignal (completo) ──────────────────────────────────┐
                                                              │
_trading_loop (5s) ←─────────────────────────────────────────┘
    │
    ├─ [G-1..G-8 gates — ver tabela acima]
    │
    ├─ BLOQUEADO → _log_signal_event(gate_outcome=Gx_BLOCKED) [await, 10 chamadas]
    │               → MongoDB: scalp_signal_log
    │               → _write_dedup_bucket() [await] → scalp_dedup_counters
    │
    └─ APROVADO  → _execute_trade(signal, config, param_snapshot)
                    │
                    ├─ consume_period_range() [drain do buffer pré-trade]
                    ├─ POST webhook → SignalStack → Tradovate bracket OCO
                    ├─ _log_signal_event(gate_outcome="EXECUTED")
                    ├─ insert scalp_trades (state="OPEN")
                    └─ first_market_tick capturado no próximo tick DataBento

_monitor_loop (5s)  ← corre em paralelo
    │  Para cada trade OPEN:
    ├─ consume_period_range() → best_price / worst_price / lifetime_best/worst
    ├─ trailing ratchet: se MFE ≥ be_pts → mover SL
    └─ SL/TP hit → _close_trade() → update scalp_trades (state="CLOSED")
                     ├─ mae_pts/mfe_pts calculados
                     └─ _persist_session_stats()

EOD transition (detectada no _trading_loop)
    ├─ flatten_all_trades("EOD_FLATTEN")
    ├─ _compute_hyp_outcomes_eod() [create_task]  → scalp_signal_log.hyp_outcome
    ├─ _check_hypothesis_expiry()  [create_task]  → hypothesis_review_queue
    └─ _check_sprint_gates()       [create_task]  → logs + status

scalp_snapshot_loop (30s) [independente]
    └─ engine.evaluate(symbol) [mesma cache 2s]
       └─ insert scalp_snapshots
```

**Propagação de mudança de config:**
`PUT /api/scalp/config/save` → `invalidate_config_cache()` → próxima iteração do `_trading_loop` chama `_get_config_cached()` → re-lê MongoDB → efectivo em ≤ 30s.

---

## Background Loops (Scalp-only, V3 removed)

| Loop | Interval | Ficheiro | Purpose |
|---|---|---|---|
| `_trading_loop` | 5s | `scalp_auto_trader.py:663` | Gate pipeline + execução. Principal loop de trading. |
| `_monitor_loop` | 5s | `scalp_auto_trader.py:1487` | Trailing ratchet + SL/TP check em posições abertas |
| `scalp_snapshot_loop` | 30s | `server.py` | Grava estado do engine em `scalp_snapshots` para AutoTune |
| `live_price_broadcaster` | 1s | `server.py` | Push de preços live via WebSocket → frontend |
| `feed_health_monitor` | 15s | `server.py` | DQS DataBento — grava `feed_health_log` |
| `scalp_scheduler` | event-driven | `scalp_scheduler.py` | Walk-forward AutoTune (D1) — poll 60s |
| `combined_scheduler` | event-driven | `scalp_combined_service.py` | Combined D1×D2 analysis — poll 60s |
| Track B observer | 10 min | `scalp_auto_trader.py:2085` | Verifica critério de readiness de activação |

---

## Key Files

| File | Purpose |
|---|---|
| `backend/server.py` | Main FastAPI app (~4,900 lines) — Scalp routes + background loops |
| `backend/services/scalp_engine.py` | Full Scalp pipeline: ScalpSignal, ScalpEngine, evaluate() |
| `backend/services/scalp_snapshot_service.py` | Parallel snapshot recording for Auto-Tune |
| `backend/services/scalp_auto_trader.py` | Execution loop: paper/live, position tracking |
| `backend/services/macro_context_service.py` | Standalone VIX/GEX service (no V3 deps) |
| `backend/services/live_data_service.py` | DataBento Live client — tick buffers for MNQ/MES |
| `backend/services/delta_zonal_service.py` | Delta zone analysis + OFI + Welford Z-score |
| `backend/services/feed_health.py` | DataBento DQS monitor |
| `backend/services/overnight_inventory.py` | Overnight gap/inventory for Scalp context |
| `backend/services/scalp_diagnostics_service.py` | D1 analysis: fire rate / block reasons / OFI Slow impact (from snapshots) |
| `backend/services/scalp_combined_service.py` | Combined D1×D2 analysis: crosses diagnostics + calibration → param suggestions + schedule |
| `backend/routes/scalp.py` | All scalp routes: signal, execute, trades, zones |
| `backend/routes/fills.py` | Trade journal (Fill Monitor) API routes |
| `backend/routes/auth.py` | Google OAuth + passcode auth |
| `frontend/src/App.js` | Main app — header nav + overlay panels (Scalp-only, V3 removed) |
| `frontend/src/components/ScalpDashboard.jsx` | Main Scalp UI with ScalpStatusBar |
| `frontend/src/components/ScalpStatusBar.jsx` | Horizontal status strip, polls /api/system/status every 15s |
| `frontend/src/components/ScalpAutoTunePanel.jsx` | Walk-forward replay / Auto-Tune UI |
| `frontend/src/components/FillMonitor.jsx` | Trade journal UI |
| `start_backend.sh` | Backend startup (waits for MongoDB, then uvicorn) |

---

## Endpoints API — Mapa de Referência

> Todos prefixados com `/api/scalp`. Backend FastAPI: `backend/routes/scalp.py`.

### Sinal e Execução
| Método | Path | Notas |
|---|---|---|
| `GET` | `/signal/{symbol}` | Chama `engine.evaluate()` fresh (ignora cache) |
| `GET` | `/signal/{symbol}/cached` | Retorna último resultado cached |
| `POST` | `/execute/{symbol}` | Execução manual de sinal |
| `GET` | `/live/{symbol}` | Live data raw do SymbolBuffer |
| `GET` | `/zones/{symbol}` | Avalia zonas para debug (sem gates) |
| `GET` | `/levels/{symbol}` | Níveis de mercado: VWAP, VP, ONH, ONL, etc. |

### AutoTrader
| Método | Path | Notas |
|---|---|---|
| `GET` | `/autotrader/status` | Estado do loop, stats, track_b_readiness |
| `POST` | `/autotrader/start` | Inicia o loop |
| `POST` | `/autotrader/stop` | Para o loop |
| `POST` | `/autotrader/reset_circuit_breaker` | Reseta G-3 manualmente |

### Trades e Posições
| Método | Path | Parâmetros relevantes |
|---|---|---|
| `GET` | `/positions` | Posições abertas |
| `GET` | `/positions/stats` | Stats de posições abertas |
| `GET` | `/trades` | `symbol`, `session`, `paper`, `days`, `state` |
| `GET` | `/trades/stats` | `days`, `symbol`, `session` |
| `POST` | `/trades/{id}/close` | Fecha trade manualmente |
| `POST` | `/trades/flatten_all` | Flatten de emergência |
| `PATCH/POST` | `/close/{position_id}` | Fecha posição por ID |

### Configuração e Auditoria
| Método | Path | Notas |
|---|---|---|
| `GET/PATCH` | `/config` | Ler / atualizar config (PATCH = save com audit log) |
| `POST/PATCH` | `/config/save` | Salva config; escreve `config_audit_log`; invalida cache |
| `PATCH` | `/config/paper-mode` | Toggle paper/live |
| `GET` | `/config-audit` | Histórico de saves — filtro `logic_changed_only=true` |

### Observabilidade e Diagnóstico
| Método | Path | Parâmetros relevantes |
|---|---|---|
| `GET` | `/signal-log` | `symbol`, `gate`, `session`, `zone_type`, `hours`(24h), `limit`(1000), `hyp_only`, `pending_hyp`, `include_executed` |
| `GET` | `/funnel` | Funil N1→N2→N3→N4 por símbolo/zona/sessão |
| `GET` | `/daily-funnel` | Funil diário com breakdown N3 |
| `GET` | `/zone-outcomes` | WR/PnL por zona — benchmark vs hipotético |
| `GET` | `/dedup-stats` | Taxas de supressão por gate × symbol (`hours=24`) |
| `GET` | `/param-audit` | Auditoria de param_snapshot por trade |
| `GET` | `/pipeline-health` | Saúde geral: missing_outcome, loop snaps, WR, D1 shadow |
| `GET` | `/shadow-obs` | Observações D1_HIGH/D1_LOW shadow |
| `GET` | `/sprint-gate` | Estado dos gates de Sprint B (N≥10, N≥30) |

### Hipóteses e Relatórios
| Método | Path | Notas |
|---|---|---|
| `POST` | `/report/compute-hyp` | Trigger manual de cálculo de hyp_outcomes (`days=1`) |
| `GET` | `/report/compute-hyp/status` | Estado do último cálculo |

### AutoTune
| Método | Path | Notas |
|---|---|---|
| `POST/PATCH` | `/tune/replay` | Replay walk-forward |
| `POST/PATCH` | `/tune/optimize` | Optimização de params |
| `GET` | `/tune/optimize/status` | Estado da optimização a correr |
| `GET` | `/tune/calibration` | Calibração D1 + sugestões de parâmetros |
| `GET` | `/tune/diagnostics` | Diagnóstico de zonas + OFI slow impact |
| `GET/POST/DELETE` | `/tune/schedule` | Agenda D1 do AutoTune |
| `POST` | `/tune/schedule/run-now` | Força corrida D1 imediata |
| `GET/POST/PATCH` | `/tune/combined` | Combined D1×D2 analysis |
| `POST` | `/tune/combined/run-now` | Força corrida D2 imediata |

### Backup e Infra
| Método | Path | Notas |
|---|---|---|
| `GET` | `/backup/status` | Estado último backup GitHub |
| `POST` | `/backup/run` | Força backup manual |
| `GET` | `/atlas/storage` | Utilização do M0 Atlas |
| `GET` | `/mode` | Modo activo (FLOW/ZONES) |
| `POST` | `/mode/{mode}` | Muda modo |
| `GET` | `/snapshots` | Query de snapshots (filtros: symbol, session, hours) |
| `GET` | `/snapshots/stats` | Contagens por status/sessão |

---

## SignalStack / Tradovate Integration

All live entries use a **single webhook call** with native Tradovate bracket fields.
Tradovate creates OCO child orders — when one side fills, the other is cancelled automatically.

### Bracket payload:
```json
{
  "symbol": "MNQM6",
  "action": "buy",
  "quantity": 1,
  "class": "future",
  "stop_loss_price": 19500.0,
  "take_profit_price": 19560.0,
  "trail_trigger": 20.0,
  "trail_stop": 10.0
}
```

### Flatten / Cancel payload (EOD ou blackout):
```json
{ "symbol": "MNQM6", "action": "cancel_all", "class": "future" }
{ "symbol": "MNQM6", "action": "sell",       "quantity": 1, "class": "future" }
```
Dois webhooks separados, em sequência. O primeiro cancela o bracket OCO, o segundo fecha a posição a mercado. O `_close_trade(skip_broker=True)` atualiza o estado interno sem duplicar chamadas.

### Campos trail_trigger / trail_stop:
- `trail_trigger` = `d30_thr_blocked` (D30 BLOCKED threshold em pts, default 20.0) — ponto a partir do qual o Tradovate activa o trailing
- `trail_stop` = `d30_thr_risk` (D30 RISK threshold em pts, default 10.0) — distância do trailing stop ao peak
- Estes valores são passados informativamente ao Tradovate; o ratchet interno do sistema (`be_pts`) é independente e tem precedência

### Pre-flight price guard:
Antes de qualquer ordem, valida preços contra preço live. Desvio >12% → bloqueado localmente (422), guardado em MongoDB (`signals_blocked` stats). Nenhum webhook enviado.

### Símbolo Tradovate (formato contrato activo):
`_tradovate_symbol(base)` — constrói `MNQM6` / `MESM6` etc. com base no mês front-month actual. Lógica em `scalp_auto_trader.py:116`.

---

## Authentication

- Google OAuth (via `/api/auth/google`) — whitelist-based
- Passcode fallback (`DASHBOARD_PASSCODE` env var)
- Session tokens stored in `localStorage` + verified server-side
- `ProtectedRoute` wraps all authenticated routes

---

## Frontend Navigation

The main Dashboard has:
- **Header nav**: Auto Trade | SignalStack | Auto Tune | Journal | Scalp
- **Scalp panel** (`activePanel === 'scalp'`): Full-screen `ScalpDashboard`
- **Sub-panels inside Scalp**: Ordens Manuais (SignalStack) | Auto Tune | Journal
- **Auto Trading panel**: `AutoTradingPanel` (legacy config UI, execution delegates to ScalpAutoTrader)
- **Fill Monitor**: Trade journal overlay

---

## AutoTrader Sizing Modes

Two modes selectable in the AutoTrader panel (Símbolos & Loop card):

- **FIXO** (default): always sends `mnq_quantity` / `mes_quantity` contracts from config. `account_size` and `risk_per_trade_pct` are reference-only.
- **RISK %**: dynamically calculates qty at execution time: `qty = floor((account_size × risk_pct/100) / (stop_pts × point_value))`. Uses `signal.s3_stop_loss_price` and `signal.last_price` for stop distance. Capped by `max_qty_risk_pct` (safety cap) and G-5 (global contracts ceiling).
  - MNQ point value: $2.00/pt; MES: $5.00/pt
  - Backend: `scalp_auto_trader.py` around line 586 (`sizing_mode` branch)

---

## Track B — Critério de Activação Live

Track B (Pullback Observer) corre em modo observer-only. Activação live requer:

| Critério | Threshold | Estado actual |
|---|---|---|
| Eventos RETURN em `pb_state_log` | ≥ 10 | 1 (2026-04-15) |
| Datas de calendário distintas | ≥ 2 | 1 |

Quando atingido: o backend loga `★★★ TRACK B READINESS ATINGIDO ★★★` (WARNING) e o campo `track_b_readiness.readiness_met=true` aparece em `/api/scalp/autotrader/status`. O monitor corre a cada 10 minutos automaticamente.

**Parâmetros actuais Track B:** `_PB_SPEED_MIN=0.8`, `_PB_OFI_MIN=0.3`, `_PB_RETURN_PCT=0.5`, `_PB_TIMEOUT_SEC=300`, `_PB_MAX_STATES=3`, `_PB_BROKEN_CYCLES=3`

**Nota:** Track B é independente do path DIRECT. O TOUCH pode ocorrer com qualidade baixa ou regime adverso — o critério de entrada é avaliado exclusivamente no momento do RETURN.

---

## Journal vs Broker PnL Discrepancies — Causas e Fixes

### 1. Stale tick buffer pré-trade (bug crítico — 2026-04-16)

**Causa:** `SymbolBuffer._period_low/_period_high` acumula ticks continuamente via `add_trade()`. O método `consume_period_range()` só é chamado pelo monitor de posições — que só corre quando há trades abertos. Se não houver trades durante horas (ex: das 19:02 às 22:24), o buffer acumula 3+ horas de extremos históricos.

Quando um novo trade abre e o monitor faz a **primeira** chamada `consume_period_range()`, recebe o range completo de horas anteriores. Isso produz:
- `period_high` histórico → activa trailing (move SL virtualmente para nível errado)
- Após activação falsa, o crash real fecha o trade ao SL virtualizado errado
- Journal regista um WIN (+$20) quando o real foi um LOSS (-$74)

**Fix:** Em `_execute_trade()`, imediatamente após registar o trade em `_open_trades`, fazer **drain** do buffer com `consume_period_range()` (resultado descartado). O monitor só vê ticks pós-abertura. Log: `AutoTrader buffer-drain {symbol}: ticks pré-trade descartados (stale low=... high=... entry=...)`.

### 2. SL threshold vs broker stop alignment

**Causa:** O sistema calcula o SL a partir do `signal.last_price` (preço do sinal). O Tradovate/PickMyTrade aplica o mesmo offset em pontos ao **fill price** (que pode diferir 1 tick do sinal) e arredonda para tick. Isso cria um gap de 0.25pt entre o SL interno e o stop real no broker.

**Fix:** `align_sl_to_tick(sl_price, action, symbol)` em `scalp_pnl.py`:
- `SELL` (SL acima entrada): arredonda para **baixo** (`math.floor`) → ex: 26359.68 → 26359.50
- `BUY` (SL abaixo entrada): arredonda para **cima** (`math.ceil`) → ex: 26443.32 → 26443.50

Aplicado em `_execute_trade()` ao `sl_price` antes de gravar; `tp_price` usa `round_to_tick()` (neutro).

### 3. Residual discrepância de PnL

Após os dois fixes acima, subsiste uma **discrepância residual** de ~$4 por trade (ex: sistema -$70, broker -$74) devida ao slippage de 1 tick na entrada:
- Sistema usa `signal.last_price` como entry (ex: 26446.75)
- Broker fill real: 26447.00 (+0.25pt = +$5/contrato × 10 = +$5 de diferença na entrada)
- PnL sistema: (26443.25 - 26446.75) × 10 × $2 = -$70
- PnL broker: (26443.25 - 26447.00) × 10 × $2 = -$74 (aprox, baseado em fill avg)

Esta discrepância residual só é eliminável com confirmação de fill do broker (não disponível actualmente via PMT/Tradovate webhook).

---

## ZONES Engine Fixes (2026-04-16)

### Fix A — Block SIGMA2_FADE_BUY + SIGMA2_FADE_SELL em RTH_OPEN ✅ IMPLEMENTADO

**Evidência (BUY):** 3/3 STOP_HIT em RTH_OPEN (17, 24, 49 min após open) → 0% WR, −$1025.  
**Argumento SELL:** Estrutural simétrico — price discovery e OFI incoerente afectam igualmente a fade de alta (+2σ). Sem evidência empírica directa de STOP_HIT em SELL, por isso shadow log cobre o lado SELL para validação retrospectiva.  
**Root cause:** Volatilidade de abertura produz wide ATR e OFI incoerente; absorção local no 2σ é indistinguível de distribuição durante price discovery.  
**Fix:** Filtro em `evaluate_zones()` após `in_zone` ser computado: remove `SIGMA2_FADE_BUY` e `SIGMA2_FADE_SELL` quando `0 ≤ on_session_minutes < 60` (RTH_OPEN = 09:30–10:29 ET).  
**Toggles independentes:**  
- `FIX_A_RTH_OPEN_BLOCK_SIGMA2_FADE_BUY = False` → reverte só o lado BUY  
- `FIX_A_RTH_OPEN_BLOCK_SIGMA2_FADE_SELL = False` → reverte só o lado SELL  
**Shadow logging:** Toda zona removida (BUY ou SELL) registada em `signal_log` com `gate_outcome="FA_SHADOW"`, `fix_a_shadow_zones`, `ofi_slow_raw`, `ofi_fast_raw`.  
**Critério de revisão:** ≥3 sessões RTH_OPEN + comparar shadow log PnL hipotético vs real por direcção.

### Fix B — F1-2 estendido: OFI slow bearish → bloqueia SIGMA2_FADE_BUY ✅ IMPLEMENTADO (hypothesis)

**Hypothesis:** Quando `ofi_slow < −0.30`, fluxo vendedor de fundo prevalece sobre absorção local; a rejeição é distribuição disfarçada, não reversão genuína.  
**Fix:** Em `evaluate_zone_entry()`, AND gate adicional para `SIGMA2_FADE_BUY`: se `ofi_slow < -FIX_B_OFI_SLOW_FADE_BUY_THRESH (0.30)` → BLOCKED com razão `"F1-2-EXT [hypothesis=True]"`.  
**HYPOTHESIS = True:** threshold −0.30 não validado (Fix C não estava activo até hoje). Rever após N≥30 trades com `ofi_slow_raw` registado.  
**Localização:** `scalp_zones.py`, função `evaluate_zone_entry()`, antes do bloco OFI fast scoring.

### Fix C — ofi_slow_raw + cvd_trend no signal_log ✅ IMPLEMENTADO

**Problema:** `scalp_signal_log` não registava o valor bruto de OFI slow (150s window), impossibilitando a validação retrospectiva do threshold Fix B.  
**Fix:** Em `_log_signal_event()` em `scalp_auto_trader.py`, adicionados campos ao doc:
- `ofi_slow_raw`: valor bruto `signal.ofi_slow` (janela 150s)
- `ofi_fast_raw`: valor bruto `signal.ofi_fast` (janela ~10s)
- `cvd_trend`: tendência CVD para diagnóstico do Bug 1
- `fix_a_shadow_zones`: lista de SIGMA2_FADE_BUY removidas por Fix A no ciclo

### Fix D — Tape Speed bónus condicional em zonas de fade ✅ IMPLEMENTADO

**Problema:** O bónus de +0.3 pts por "tape a secar" (`speed_ratio ≤ 0.9`) era aplicado incondicionalmente em qualquer zona de fade. Tape lento com OFI slow contra a direcção do trade não confirma reversão — pode ser pausa antes de continuation.  
**Correcção:** Bónus aplicado apenas quando OFI slow está alinhado:
- LONG fades (SIGMA2_FADE_BUY, etc.): bónus se `ofi_slow >= 0` (não bearish)
- SHORT fades (SIGMA2_FADE_SELL, etc.): bónus se `ofi_slow <= 0` (não bullish)  

**Toggle:** `FIX_D_TAPE_SPEED_CONDITIONAL = True` em `scalp_zones.py` — `False` restaura comportamento original.  
**Visibilidade:** Quando bónus suspenso, a razão é registada em `score_breakdown.reasons` com OFI slow, direcção e ratio actual.  
**Efeito esperado:** Reduz inflação de score em entradas de fade com fluxo de ordem médio-prazo adverso. Não é novo critério — é correcção de comportamento existente.

### Fix E — CVD opõe-se à fade → penalidade −0.5 pts ✅ IMPLEMENTADO

**Problema:** CVD FALLING durante uma fade LONG (comprar em -2σ) indica pressão vendedora de médio prazo contra a entrada. CVD RISING durante uma fade SHORT indica pressão compradora de médio prazo contra a entrada. Em ambos os casos, o CVD não confirma a reversão — o bónus existente (+0.5 quando alinhado) não capturava o caso adverso.  
**Fix:** Penalidade simétrica em zonas de fade quando CVD se opõe:
- `zone.direction == "LONG"` + `cvd_trend == "FALLING"` → −0.5 pts
- `zone.direction == "SHORT"` + `cvd_trend == "RISING"` → −0.5 pts

**Intervalo CVD resultante por tipo de zona:**
- Fade: [−0.5, +0.5] — assimetria total de 1.0 pt
- Momentum/Breakout: [0, +0.5] — sem penalidade (CVD adverso já é capturado por OFI slow)

**Toggle:** `FIX_E_CVD_FADE_PENALTY_ENABLED = True`, `FIX_E_CVD_FADE_PENALTY_PTS = 0.5`  
**Visibilidade:** Razão registada em `score_breakdown.reasons` com cvd_trend e direcção.  
**Nota:** CVD `reasons.append` adicionado também ao bónus de alinhamento existente (+0.5) para paridade de visibilidade no breakdown.

### Item 3 — gap_open, snapshots_in_regime, range_consumed ✅ IMPLEMENTADO

Três filtros de contexto estrutural adicionados em `evaluate_zones()` após o bloco Fix A, com toggles de emergência individuais:

**Fix 3a — gap_open:** `abs(rth_open_price − d1_poc) > 0.5×ATR` durante `RTH_OPEN` → suprime `SIGMA2_FADE_*` e `EMA_PULLBACK_*`. Em dias de gap (abertura longe do POC D-1), o price discovery é violento e fades são estruturalmente arriscadas.  
**Fix 3b — snapshots_in_regime:** Se `snapshots_in_regime < 3` (primeiras 3 avaliações num regime novo) → suprime todas as fades. Regime não confirmado = incerteza alta.  
**Fix 3c — range_consumed v2:** `(session_HOD − session_LOD) / (D1_HIGH − D1_LOW) > 1.5` → suprime todas as fades. Compara range de hoje com range RTH do dia anterior — escalas equivalentes.  
  *Redesign 2026-04-16:* versão original usava ATR_M1 como denominador (escalas incompatíveis → bloqueava 100% dos trades). Substituído por `D1_HIGH−D1_LOW` (já existente no pipeline, zero nova infraestrutura). Threshold ajustado de 1.8 para 1.5×. Exemplo: hoje 284/394=0.72× → não activa; dia excepcional 700/394=1.78× → activa.  
  `evaluate_zones()` recebe `d1_high`/`d1_low` como parâmetros adicionais; `scalp_engine.py` passa `signal.d1_high`/`signal.d1_low`.

**Tracking em ScalpEngine:** `_session_hod`, `_session_lod` (por símbolo+data), `_regime_snapshot_counts` (por símbolo).  
**Toggles:** `FIX_3_GAP_OPEN_ENABLED`, `FIX_3_SNAPSHOTS_ENABLED`, `FIX_3_RANGE_CONSUMED_ENABLED` (todos `True`).

---

### D30 — Gate activo de deslocamento de preço em 30 minutos ✅ ACTIVO (Fase 2)

**Evidência empírica:** Simulação com 57 trades Apr 14–17:
- `|D30| > 20 pts` → BLOCKED: WR=33%, EV=−78.94 pts/semana
- `|D30| 10–20 pts` → RISK:    WR=43%, EV=−11.00 pts
- `|D30| ≤ 10 pts`  → OK:      WR=56%, EV=+3.88 pts
- Sem filtro: semana −44.32 pts. Com filtro: +34.62 pts.

**Fase 2 (activa desde Apr 17 2026) — gate hard antes de evaluate_zones:**

```
|D30| > 20 pts  → D30_BLOCKED: trade rejeitado antes de avaliar zonas
|D30| 10–20 pts → D30_RISK:    sinal bloqueado se zone_quality ≠ STRONG
|D30| ≤ 10 pts  → OK:          fluxo normal
D30 = None      → sem gate (buffer insuficiente / gap Globex)
```

`signal.d30_state` persistido no MongoDB (`disp_30m` + `d30_state`) para comparação com/sem gate.

**Ficheiros:** `scalp_engine.py` — helper `_compute_disp_30m()`, campos `ScalpSignal.disp_30m` / `ScalpSignal.d30_state`, gate BLOCKED (antes de `evaluate_zones`), gate RISK (após `zones_result`). `scalp_auto_trader.py` — campos `disp_30m` / `d30_state` no documento MongoDB.

**Bug evitado:** usa aritmética directa em epoch-seconds (`abs(bar["ts"] - target_ts)`), não `timedelta.seconds`.

---

### Item 4 — RTH_OPEN como regime nativo S1 ✅ IMPLEMENTADO

**Refactorização:** `ScalpDayRegime.RTH_OPEN` adicionado ao enum. Em `evaluate_zones()`, após `apply_regime_hysteresis()`, override via tempo: `0 ≤ session_min < 60 → regime = RTH_OPEN`. Bypass correcto — regime baseado em tempo não deve ser debounced.

**Consequências:**  
- `signal.day_regime` reporta `"RTH_OPEN"` durante os primeiros 60 min → dashboard e logs mostram o regime real  
- Fix A refactorizado: condição mudou de `_fix_a_in_window = on_session_minutes < 60` para `regime == RTH_OPEN` — semântica idêntica, arquitectura limpa  
- Fix 3a (gap_open) também usa `regime == RTH_OPEN`  
- `evaluate_zones()` aceita `snapshots_in_regime`, `session_hod`, `session_lod` como parâmetros novos

---

### Item 5 — Price vs RTH Open como bias intraday ✅ IMPLEMENTADO

**Lógica:** `rth_open_price` injectado nos `levels` (em `scalp_engine.py` antes de `evaluate_zones()`). Threshold: `abs(price − open) > 0.10×ATR`.  
- `price > open + threshold` → `price_vs_rth_open = "ABOVE"`, `regime_bias = "BULLISH"`  
- `price < open − threshold` → `price_vs_rth_open = "BELOW"`, `regime_bias = "BEARISH"`

**Efeito no scoring:** Bónus de +0.3 pts em fades alinhadas com o bias:  
- fade BUY + bias BULLISH: mean-reversion valid (compra abaixo do open RTH)  
- fade SELL + bias BEARISH: mean-reversion valid (vende acima do open RTH)  
Sem penalidade por oposição — conservador até N≥30 dados.

**Toggles:**
- `FIX_5_RTH_BIAS_ENABLED = True`, `FIX_5_RTH_BIAS_SCORE = +0.3` (bónus alinhado)
- `FIX_5_RTH_BIAS_PENALTY_ENABLED = True`, `FIX_5_RTH_BIAS_PENALTY = -0.3` (penalidade oposto — simétrico)
- `FIX_5_RTH_BIAS_ATR_THRESH = 0.50` (corrigido de 0.10)

**Efeito total:** swing ±0.6 pts entre fade alinhada e oposta. Fade SELL quando bias=BULLISH perde 0.3 pts; fade BUY quando bias=BEARISH perde 0.3 pts. hypothesis:True — calibrar com N≥30.  
**Campos novos:** `signal.price_vs_rth_open`, `signal.regime_bias` (em `signal.to_dict()["zones"]`)  
**Persistência:** `scalp_snapshots.zones.price_vs_rth_open` + `zones.regime_bias` + `levels.rth_open_price` ✅ | `scalp_signal_log.price_vs_rth_open` + `signal_log.regime_bias` ✅

---

### Item 6 — CVD como confirmação de regime S1 ✅ IMPLEMENTADO

**Lógica:** Após detecção de regime, compara `cvd_trend` vs direcção do regime:  
- `EXPANSION_BULL` + `RISING` → `regime_cvd_conf = "CONFIRMED"`  
- `EXPANSION_BULL` + `FALLING` → `regime_cvd_conf = "CONTESTED"`  
- `EXPANSION_BEAR` + `FALLING` → `regime_cvd_conf = "CONFIRMED"`  
- `EXPANSION_BEAR` + `RISING` → `regime_cvd_conf = "CONTESTED"`  
- `ROTATION`, `RTH_OPEN`, `BREAKOUT`, `UNDEFINED` → `"NEUTRAL"`

**Informativo apenas:** sem gate hard — aguarda N≥30 por categoria para calibrar impacto.  
**Toggle:** `FIX_6_CVD_REGIME_CONF_ENABLED = True`  
**Campo novo:** `signal.regime_cvd_conf` (em `signal.to_dict()["zones"]`)  
**Persistência:** `scalp_snapshots.zones.regime_cvd_conf` ✅ | `scalp_signal_log.regime_cvd_conf` ✅

---

### Bug 1 — cvd_trend="?" Diagnóstico

**Análise:** `signal.cvd_trend = live_data.get("cvd_trend", "NEUTRAL")` é atribuído na linha 975 de `scalp_engine.py`. `SymbolBuffer` nunca emite "?". O "?" observado em scalp_trades é provavelmente artefacto de sessões de warm-up (antes do primeiro `calculate_indicators()`), onde `SymbolBuffer.cvd_trend` é ainda "NEUTRAL" e não "RISING"/"FALLING".  
**Monitoring:** Fix C adiciona `cvd_trend` ao signal_log — próximas N sessões confirmarão se o valor é sempre NEUTRAL/RISING/FALLING ou se existe outro caminho para "?".

### Bug 2 — pb_state_log from_state=None/to_state=None

**Análise:** Os documentos `pb_state_log` usam `state_from`/`state_to` (não `from_state`/`to_state`). A observação de "None" em 51 entradas usou os nomes de campo errados. Os dados reais estão correctos. Não é um bug de código.

### Bug 3 — Track B readiness reseta para 0

**Análise:** `_check_track_b_readiness()` lê do MongoDB (`count_documents({"event": "RETURN"})`), não da memória. Não zera em restart. Leitura actual: 1/10 RETURN events, 1/2 datas distintas. Sem fix necessário — o contador é persistente via MongoDB.

---

## Action Items Pós-Coleta (Fix A + Fix C) — PENDENTE

**Critério de activação: ≥3 sessões RTH completas (segunda a sexta) com Fix A + Fix C activos.**  
Verificar progresso contando entradas em `scalp_signal_log` com `ofi_slow_raw` não-nulo e `zone_type = "SIGMA2_FADE_BUY"`.

| # | Item | Como executar | Status |
|---|---|---|---|
| 1 | **Validar Fix B** — confirmar/ajustar threshold OFI slow −0.30 | Consultar `scalp_signal_log` onde `zone_type=SIGMA2_FADE_BUY` e `ofi_slow_raw` presente. Ver distribuição — se maioria > −0.30, ajustar threshold. Mudar `FIX_B_HYPOTHESIS = False` e `FIX_B_OFI_SLOW_FADE_BUY_THRESH` em `scalp_zones.py` quando N≥30. | ⏳ Aguarda dados |
| 2 | **Avaliar shadow log Fix A (BUY + SELL)** — decidir se 60 min é certo e se SELL deve manter-se bloqueado | Consultar `scalp_signal_log` onde `gate_outcome = "FA_SHADOW"`. Separar por `zone_type`: SIGMA2_FADE_BUY e SIGMA2_FADE_SELL. Ver minuto de sessão e direcção do mercado após cada evento. Se SELL entre 0–59 min teria ganho consistentemente → `FIX_A_RTH_OPEN_BLOCK_SIGMA2_FADE_SELL = False`. Se entradas BUY entre 30–59 min teriam ganho → reduzir `FIX_A_RTH_OPEN_DURATION_MIN` de 60 para 30. | ⏳ Aguarda dados |
| 3 | **Confirmar Bug 1 (cvd_trend)** — verificar se aparece valor inesperado | Consultar `scalp_signal_log` com campo `cvd_trend`. Se valor for sempre NEUTRAL/RISING/FALLING → bug inexistente. Se aparecer "?" ou null → rastrear hora do dia e confirmar warm-up como causa. | ⏳ Aguarda dados |
| 4 | **Track B readiness** — verificar se contador avançou | Verificar `/api/scalp/autotrader/status` campo `track_b_readiness`. Critério: 10 RETURN events + 2 datas distintas. Sem acção até atingido. | ⏳ 1/10 events |
| 5 | **Calibração global OFI slow fade (0.55 → ?)** — avaliar se threshold global está correcto | Após Fix B validado, usar dados de `ofi_slow_raw` de todas as fade zones para ver se 0.55 é tolerante demais. Ajustar `OFI_SLOW_BLOCK_FADE` em `scalp_zones.py` apenas se padrão claro. | ⏳ Bloqueado por item 1 |

---

## Auditoria de Persistência (2026-04-17)

Auditoria sistemática de todo o estado em memória que deve sobreviver a restarts.

| Estado | Localização | Persiste? | Impacto |
|---|---|---|---|
| ATR cache | `scalp_engine._atr_cache` | ✅ Snapshot → warm-start | — |
| VWAP / VP | caches | ✅ Snapshot → warm-start | — |
| Posições abertas | `scalp_auto_trader._open_trades` | ✅ MongoDB `scalp_trades` | — |
| Cooldown por símbolo | `_last_trade_ts` | ✅ `scalp_trader_state` | — |
| ScalpConfig / thresholds | session_params | ✅ MongoDB → restore | — |
| Track B readiness | `_track_b_readiness` | ✅ `pb_state_log` query | — |
| OFI/CVD | tick buffer rolling | ✅ Recalculado em <30s | — |
| Welford Z-Scores | `delta_zonal_service` | ✅ **CORRIGIDO 17/04** (5 min + shutdown) | — |
| **RTH open price** | `_rth_open_prices` | ✅ **CORRIGIDO 17/04** (restore de snapshot de hoje ET) | Fix 3a + Fix 5 |
| **Session HOD/LOD** | `_session_hod/_lod` | ✅ **CORRIGIDO 17/04** (max/min last_price dos snapshots de hoje) | Fix 3c |
| **Circuit breaker G-3/G-4** | `_session_stats` | ✅ **CORRIGIDO 17/04** (persist após cada trade + restore por data ET) | Segurança diária |
| Regime snapshot counts | `_regime_snapshot_counts` | ❌ Default 999 no restart (safe — Fix 3b passa) | Mínimo |

**Notas de implementação:**
- RTH open: filtrado por `recorded_at >= midnight ET hoje` — evita importar open de ontem durante Globex
- HOD/LOD: computed de todos os snapshots de hoje; `_ET` date garante alinhamento com chave `SYMBOL:YYYY-MM-DD`
- Circuit breaker: gravado em `scalp_trader_state._id="session_stats"` com campo `date_et`; restore só actua se `date_et == hoje ET` (reset diário automático continua a funcionar)

---

## Robustness Fixes — 2026-04-19

### P0.1 — Chave canónica do cache de `evaluate()`
**Arquivo:** `backend/services/scalp_engine.py` — linha ~1088  
**Fix:** `_cache_key` agora inclui `disabled_zone_types`, `zone_min_score_overrides`, `zone_min_confluence_overrides`, `r1_block`, `r2_block` como tuplo canónico (sorted). Evita colisão entre callers com parâmetros diferentes dentro da janela de 2s TTL.

### P0.4 — Backup das colecções de calibração Track B
**Arquivo:** `backend/services/github_backup_service.py` — `COLLECTIONS_TO_EXPORT`  
**Fix:** `pb_state_log` e `scalp_signal_log` adicionadas ao backup automático. Essenciais para restore operacional do Track B (critério ≥30 RETURN events) e audit de gates pós-restore.

### Limpeza readiness Track B
**Arquivo:** `backend/services/scalp_auto_trader.py`  
**Removido:**
- `self._track_b_readiness` dict (hardcoded, nunca actualizado — enganador na status API)
- `self._track_b_readiness_checked_ts` float (nunca actualizado)
- Campo `"track_b_readiness"` do `get_status()` response
- `_check_track_b_readiness()` método (corpo: apenas `return`)
- Código morto de `_execute_pb_trade` abaixo do `return None` (~160 linhas, incluindo `tb_forced_paper` / "readiness pendente")  
**Mantido:** bloco `readiness` no `/daily-funnel` (métricas reais de `pb_state_log` — monitoring genuíno).

### D30 threshold adaptativo
**Arquivo:** `backend/services/scalp_engine.py` — gate D30 Fase 2 (~linha 1263)  
**Antes:** thresholds fixos `BLOCKED > 20.0 pts` / `RISK > 10.0 pts` (calibrados na simulação Apr 14–17).  
**Depois:** thresholds adaptativos com floor fixo:
```
_d30_thr_blocked = max(20.0, 1.5  × ATR_intraday)
_d30_thr_risk    = max(10.0, 0.75 × ATR_intraday)
```
ATR lido do cache existente (`_atr_cache[symbol]`, TTL 60s) antes do gate; fallback a `ATR_MIN_FALLBACK` se cache frio.  
Floor garante comportamento idêntico ao anterior em baixa vol (ATR ≤ 13.3 pts MNQ).  
Em alta vol (ex.: ATR=16): BLOCKED=24.0, RISK=12.0 — reduz falso bloqueio em dias de expansão.  
Mensagens de log e `s2_block_reasons` agora incluem `thr=XX.X atr=XX.X` para validação retrospectiva.

---

## Gate Observability — 2026-04-19

**Arquivo:** `backend/services/scalp_auto_trader.py`  
**Implementação:** Contadores in-memory por gate × símbolo, expostos em `GET /autotrader/status` → campo `gate_counters`. Reset automático diário junto com os contadores G-3/G-4.  

**Gates monitorados:**
| Gate | Origem | Quando dispara |
|---|---|---|
| `FA_SHADOW` | Autotrader | Fix A bloqueia SIGMA2_FADE em RTH_OPEN |
| `D30_BLOCKED` | Engine → Autotrader | Deslocamento 30min > 1.5×ATR |
| `D30_RISK` | Engine → Autotrader | Deslocamento 30min > 0.75×ATR |
| `MODE_BLOCKED` | Autotrader | `auto_trade_flow=False` ou `auto_trade_zones=False` |
| `G7_BLOCKED` | Autotrader | Warm-up RTH_OPEN/OVERNIGHT não concluído |
| `G8_BLOCKED` | Autotrader | Daily bias filter (SELL em ABOVE_2SD) |
| Outros `scalp_status` | Engine → Autotrader | Qualquer status de bloqueio com zona detectada |

**Estrutura do campo `gate_counters`:**
```json
{
  "D30_BLOCKED": {"MNQ": 14, "MES": 6, "_total": 20},
  "FA_SHADOW":   {"MNQ": 4,  "MES": 1, "_total": 5},
  "G8_BLOCKED":  {"MNQ": 2,  "_total": 2}
}
```

**Diagnóstico:** "Por que parou de operar" resolúvel em <1s via `GET /autotrader/status` sem query MongoDB ou leitura de logs.

---

## Performance Backlog (P0)

- Master loop centralizing evaluate() calls (reduce redundant computations)
- WebSocket push for S3 signals (eliminate polling latency)
- `_get_trades()` without deque copy (memory optimization)
- **Paginação/limites em endpoints com `to_list(None)` pesados** — activar quando: (a) endpoint com latência medida > 2s, ou (b) janelas de análise multi-dia forem introduzidas. Alvos principais: `scalp_snapshots` cursors em `/daily-funnel` (linhas ~2929–2945 `scalp.py`) e pipelines de agregação com `to_list(None)` nas rotas de zona (~3560–3562). Actualmente sem risco real (queries já filtradas por data, resultado <800 docs/dia).

## Track B — Backlog Relacional

### Archetype específico por tipo de zona
**Quando implementar:** quando `pb_state_log` tiver ≥ 30 RETURN events com `is_ema_zone: false` — amostra mínima para validar se a lógica discrimina outcomes.

**Situação atual:** `_classify_tb_archetype` usa a mesma lógica para todas as zonas (z_level vs VAL/VWAP/VAH). Funciona bem para EMA zones (`is_ema_zone: true`). Para outros tipos, os resultados são tautológicos:
- `VWAP_PULLBACK` → sempre `NEAR_VWAP → RANGE_FADE` (z_level = próprio VWAP)
- `D1_VAH/VAL_FADE` → sempre `CONFLUENCE_D1` (z_level = D1_VAH/VAL)
- `D1_POC_MAGNET` → precisa de lógica por distância ao POC em ATR

**Lógica ideal por zona:**
| Zona | Classificação ideal |
|------|-------------------|
| EMA_PULLBACK | Posição EMA vs VAL/VWAP/VAH (já implementado) |
| VWAP_PULLBACK | Regime (S1) + distância do pullback em σ (vwap_std) |
| D1_VAH/VAL_FADE | Regime + gap_open_atr_mult |
| D1_POC_MAGNET | Distância preço→POC vs ATR (1×, 1.5×, 2×) |

**Arquivo:** `backend/services/scalp_auto_trader.py` — método `_classify_tb_archetype` (~linha 1793)

### SL/TP e Score por archetype
**Quando implementar:** após validação histórica mostrar que archetypes discriminam outcomes (WR diferente entre TREND/RANGE/FADE com N≥30 por archetype).
**Dados disponíveis em:** `pb_state_log.archetype` + `scalp_trades.param_snapshot.archetype`

---

## Backlog — Melhoria 1: Pipeline de calibração automática das hipóteses

### O que é
Job periódico que analisa cohorts de sinais bloqueados por hipótese (Fix A, Fix B, CVD bias Fix 5/6) e gera recomendação textual com WR/EV e intervalo de confiança de Wilson por regime/sessão. Substitui ajuste manual ad hoc por ciclo estatístico controlado.

### Infra já disponível (sem esforço adicional)
- `scalp_combined_service.py` — scheduler, auto-apply, confidence labels, `run_combined_now()`
- `scalp_hyp_outcomes.py` — motor de outcomes (TP_HIT/SL_HIT/EOD/NO_DATA + `hyp_pnl_pts`)
- `scalp_signal_log` — grava `gate_outcome`, `block_gate`, `s1_regime`, `session_label`, `hyp_outcome`, `hyp_pnl_pts`

### Trabalho necessário (~300–400 linhas novo ficheiro)
1. `scalp_hyp_calibration.py` — função `_analyse_hypothesis_cohorts()`:
   - Query por cohort de fix (`gate_outcome` contém `"F1-2-EXT"` para Fix B, `"FIX_A_RTH_OPEN"` para Fix A)
   - Calcula WR / EV / Wilson CI a 95% por cohort
   - Gera recomendação: "relaxar threshold", "manter", "apertar"
2. Hook no scheduler de combined analysis (intervalo configurável, ex.: semanal)
3. Resultado persistido em `scalp_combined_history` com campo `type: "hypothesis_calibration"`

### Critério de activação — implementar quando:
| Condição | Valor mínimo | Como verificar |
|---|---|---|
| Sinais Fix B bloqueados com `hyp_outcome` computado | ≥ 30 | `db.scalp_signal_log.countDocuments({"gate_outcome": {$regex: "F1-2-EXT"}, "hyp_outcome": {$exists: true}})` |
| Sinais Fix A (RTH_OPEN shadow) com `hyp_outcome` | ≥ 30 | `db.scalp_signal_log.countDocuments({"gate_outcome": "FA_SHADOW", "hyp_outcome": {$exists: true}})` |
| `hyp_outcomes` a correr regularmente | Scheduler activo | Endpoint `/scalp/hyp-outcomes/status` |

**Nota:** os dados estão a acumular desde que `scalp_hyp_outcomes.py` foi implantado. O job só produz output útil quando N≥30 por cohort — construir antes disso apenas gera "amostra insuficiente" repetidamente.

**Ficheiros alvo:** `backend/services/scalp_hyp_calibration.py` (novo), `backend/services/scalp_combined_service.py` (hook no scheduler), `backend/routes/scalp.py` (endpoint de status/resultado)

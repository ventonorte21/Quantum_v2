"""
scalp_hyp_outcomes.py
─────────────────────
Motor de outcomes hipotéticos para sinais bloqueados no scalp_signal_log.

Para cada sinal bloqueado com preços S3 disponíveis (entry/SL/TP), escaneia
scalp_snapshots.last_price no período após o bloco e determina o outcome real
que teria ocorrido:
  - TP_HIT              : entry atingida → take-profit tocado antes do SL
  - SL_HIT              : entry atingida → stop-loss tocado antes do TP
  - EOD                 : sessão terminou sem TP/SL — PnL mark-to-market
  - ENTRY_NEVER_REACHED : preço nunca voltou ao nível de entrada após o bloco
  - DUPLICATE           : sinal idêntico (symbol+zone_type+direction, <10 min)
  - NO_DATA             : snapshots insuficientes para determinar outcome

Outputs persistidos directamente no documento signal_log via $set:
  hyp_outcome         : str (ver acima)
  hyp_pnl_pts         : float | None  — PnL em pontos (positivo = ganho)
  hyp_exit_price      : float | None  — preço de saída
  hyp_exit_at         : datetime | None
  hyp_entry_reached   : bool | None   — True se preço tocou entry ± 1 tick
  hyp_computed_at     : datetime
  hyp_computed        : True

Notas de integridade (BC-8 / 2026-04-20):
  P2+P5 — entry_reached: TP/SL só são declarados depois de price ≤ entry+1tick
          (LONG) ou price ≥ entry-1tick (SHORT). Sinais D30_BLOCKED com entry a
          20+ pts do preço actual não inflatam os contadores.
  P4    — Deduplicação: sinais com mesmo symbol+zone_type+direction a menos de
          DEDUP_WINDOW_SECONDS são marcados DUPLICATE e não contam como amostra
          independente.
"""
from __future__ import annotations

import logging
from datetime   import datetime, timezone, timedelta
from typing     import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ── Constantes ────────────────────────────────────────────────────────────────

TICK_SIZE_PTS       = 0.25          # 1 tick = 0.25 pontos (MNQ e MES)
EOD_GAP_HOURS       = 3.0           # gap de preços > 3h = fim de sessão
DEDUP_WINDOW_SECONDS = 600          # 10 min — janela de deduplicação por zona
DEFAULT_TICKS_SL    = {"MNQ": 6,  "MES": 4}
DEFAULT_TICKS_TP    = {"MNQ": 10, "MES": 8}

# ── Helpers ───────────────────────────────────────────────────────────────────

def _parse_ts(v) -> Optional[datetime]:
    if isinstance(v, datetime):
        return v.replace(tzinfo=timezone.utc) if v.tzinfo is None else v
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except Exception:
        return None


def _is_long(action: Optional[str], zone_type: Optional[str]) -> bool:
    """Determina direcção: BUY=long, SELL=short. Deriva de zone_type se action for None."""
    if action:
        return action.upper() in ("BUY", "LONG")
    zt = (zone_type or "").upper()
    return zt.endswith("_BUY") or "BUY" in zt


def _derive_sl_tp(
    entry: float,
    is_long: bool,
    symbol: str,
    param_snapshot: Dict,
) -> Tuple[float, float]:
    """
    Reconstrói SL e TP a partir de entry + config de ticks.
    Usado para sinais antigos que não têm s3_sl_price/s3_tp_price armazenados.
    """
    sym = (symbol or "MNQ").upper()
    snap = param_snapshot or {}

    sl_key = f"sl_ticks_{sym.lower()}"
    tp_key = f"tp_ticks_{sym.lower()}"
    sl_ticks = float(snap.get(sl_key) or DEFAULT_TICKS_SL.get(sym, 6))
    tp_ticks = float(snap.get(tp_key) or DEFAULT_TICKS_TP.get(sym, 10))

    sl_pts = sl_ticks * TICK_SIZE_PTS
    tp_pts = tp_ticks * TICK_SIZE_PTS

    if is_long:
        return entry - sl_pts, entry + tp_pts
    else:
        return entry + sl_pts, entry - tp_pts


# ── Engine principal ──────────────────────────────────────────────────────────

def compute_hyp_outcome(
    signal_doc: Dict[str, Any],
    prices: List[Tuple[datetime, float]],
) -> Dict[str, Any]:
    """
    Calcula o outcome hipotético de um sinal bloqueado.

    Lógica de integridade (P2+P5):
    ─────────────────────────────
    O scan verifica primeiro se o preço regressou ao nível de entrada
    (entry ± 1 tick) antes de declarar TP_HIT ou SL_HIT. Se o preço nunca
    tocou a entrada, o outcome é ENTRY_NEVER_REACHED (hyp_pnl_pts=None).
    Isto é crítico para sinais D30_BLOCKED onde o preço pode estar a 20+
    pontos da zona quando o bloco ocorre.

    Args:
        signal_doc : documento do scalp_signal_log
        prices     : lista ordenada de (timestamp, last_price) do mesmo symbol
                     a partir do momento do bloco (já filtrada externamente)

    Returns:
        dict com hyp_outcome, hyp_pnl_pts, hyp_exit_price, hyp_exit_at,
        hyp_entry_reached, hyp_computed_at, hyp_computed=True
    """
    now = datetime.now(timezone.utc)
    result_base = {
        "hyp_computed":       True,
        "hyp_computed_at":    now,
        "hyp_outcome":        "NO_DATA",
        "hyp_pnl_pts":        None,
        "hyp_exit_price":     None,
        "hyp_exit_at":        None,
        "hyp_entry_reached":  None,
    }

    if not prices:
        return result_base

    # ── Obter entry/SL/TP ──────────────────────────────────────────────────
    entry = (
        signal_doc.get("s3_entry_price")
        or signal_doc.get("zone_level")
    )
    if not entry or float(entry) <= 0:
        return result_base

    entry   = float(entry)
    sl_raw  = signal_doc.get("s3_sl_price")
    tp_raw  = signal_doc.get("s3_tp_price")
    action  = signal_doc.get("s3_action")
    sym     = (signal_doc.get("symbol") or "MNQ").upper()
    zt      = signal_doc.get("zone_type") or ""
    long    = _is_long(action, zt)

    if sl_raw and tp_raw:
        sl = float(sl_raw)
        tp = float(tp_raw)
    else:
        snap = signal_doc.get("param_snapshot") or {}
        sl, tp = _derive_sl_tp(entry, long, sym, snap)

    # Validação básica de consistência
    if long:
        if not (sl < entry < tp):
            return result_base
    else:
        if not (tp < entry < sl):
            return result_base

    # ── Scan de preços ─────────────────────────────────────────────────────
    # P2+P5: registar se o preço tocou a entrada antes de verificar TP/SL.
    # Tolerância de 1 tick para absorver spread/slippage de logging.
    entry_tol      = TICK_SIZE_PTS        # 0.25 pts
    entry_reached  = False
    last_price:    Optional[float]    = None
    last_ts:       Optional[datetime] = None
    prev_ts:       Optional[datetime] = None

    for p_ts, price in prices:
        # ── Detectar gap de EOD (> EOD_GAP_HOURS sem snapshot) ─────────────
        if prev_ts is not None:
            gap_h = (p_ts - prev_ts).total_seconds() / 3600.0
            if gap_h >= EOD_GAP_HOURS:
                break

        prev_ts    = p_ts
        last_price = price
        last_ts    = p_ts

        # ── Verificar se a entrada foi tocada (P2+P5) ───────────────────────
        if not entry_reached:
            if long  and price <= entry + entry_tol:
                entry_reached = True
            elif not long and price >= entry - entry_tol:
                entry_reached = True

        # ── Só verificar TP/SL após entry confirmada ────────────────────────
        if entry_reached:
            if long:
                if price >= tp:
                    pnl = round(tp - entry, 4)
                    return {**result_base,
                            "hyp_outcome":       "TP_HIT",
                            "hyp_pnl_pts":       pnl,
                            "hyp_exit_price":    tp,
                            "hyp_exit_at":       p_ts,
                            "hyp_entry_reached": True}
                if price <= sl:
                    pnl = round(sl - entry, 4)
                    return {**result_base,
                            "hyp_outcome":       "SL_HIT",
                            "hyp_pnl_pts":       pnl,
                            "hyp_exit_price":    sl,
                            "hyp_exit_at":       p_ts,
                            "hyp_entry_reached": True}
            else:
                if price <= tp:
                    pnl = round(entry - tp, 4)
                    return {**result_base,
                            "hyp_outcome":       "TP_HIT",
                            "hyp_pnl_pts":       pnl,
                            "hyp_exit_price":    tp,
                            "hyp_exit_at":       p_ts,
                            "hyp_entry_reached": True}
                if price >= sl:
                    pnl = round(entry - sl, 4)
                    return {**result_base,
                            "hyp_outcome":       "SL_HIT",
                            "hyp_pnl_pts":       pnl,
                            "hyp_exit_price":    sl,
                            "hyp_exit_at":       p_ts,
                            "hyp_entry_reached": True}

    # ── Fim do scan ────────────────────────────────────────────────────────

    # P2+P5: entrada nunca atingida → sinal fictício, sem PnL
    if not entry_reached:
        return {**result_base,
                "hyp_outcome":       "ENTRY_NEVER_REACHED",
                "hyp_pnl_pts":       None,
                "hyp_exit_price":    None,
                "hyp_exit_at":       None,
                "hyp_entry_reached": False}

    # EOD: entry foi atingida mas sessão fechou sem TP/SL → mark-to-market
    if last_price is not None and last_ts is not None:
        if long:
            pnl = round(last_price - entry, 4)
        else:
            pnl = round(entry - last_price, 4)
        return {**result_base,
                "hyp_outcome":       "EOD",
                "hyp_pnl_pts":       pnl,
                "hyp_exit_price":    last_price,
                "hyp_exit_at":       last_ts,
                "hyp_entry_reached": True}

    return result_base


# ── Batch compute ─────────────────────────────────────────────────────────────

async def compute_all_pending(database, days_back: int = 90) -> Dict[str, int]:
    """
    Processa todos os sinais bloqueados no signal_log que ainda não têm
    hyp_computed=True e têm entry/SL/TP disponíveis.

    P4 — Deduplicação:
    ──────────────────
    Sinais com mesmo (symbol + zone_type + direction) separados por menos de
    DEDUP_WINDOW_SECONDS são marcados como DUPLICATE e não entram na amostra
    estatística. O primeiro sinal da sequência é sempre processado normalmente.

    Returns:
        {"processed": N, "skipped": M, "errors": K, "duplicates": D}
    """
    sig_col  = database["scalp_signal_log"]
    snap_col = database["scalp_snapshots"]
    now      = datetime.now(timezone.utc)
    date_min = now - timedelta(days=days_back)

    # Sinais candidatos: bloqueados, com zone_type, sem hyp_computed
    # MODE_BLOCKED excluído: sinais de modo desactivado (FLOW quando só ZONES está activo)
    # FA_SHADOW excluído: zonas shadow não têm preços S3 reais
    query = {
        "ts":           {"$gte": date_min},
        "gate_outcome": {"$nin": ["EXECUTED", "FA_SHADOW", "MODE_BLOCKED"]},
        "zone_type":    {"$nin": [None, "", "None", "?"]},
        "hyp_computed": {"$ne": True},
        "$or": [
            {"s3_entry_price": {"$ne": None}},
            {"zone_level":     {"$ne": None}},
        ],
    }

    candidates = await sig_col.find(query, {
        "_id": 1, "ts": 1, "symbol": 1, "zone_type": 1,
        "s3_action": 1, "s3_entry_price": 1, "s3_sl_price": 1, "s3_tp_price": 1,
        "zone_level": 1, "param_snapshot": 1,
    }).sort("ts", 1).to_list(None)

    if not candidates:
        return {"processed": 0, "skipped": 0, "errors": 0, "duplicates": 0}

    # ── P4: Detectar duplicados ────────────────────────────────────────────
    # Manter registo do último ts por chave (symbol|zone_type|direction).
    # Só o primeiro sinal de uma sequência dentro da janela conta.
    recent_key_ts: Dict[str, datetime] = {}
    duplicate_ids: set = set()

    for doc in candidates:
        ts  = _parse_ts(doc.get("ts"))
        sym = (doc.get("symbol") or "MNQ").upper()
        zt  = doc.get("zone_type") or ""
        act = doc.get("s3_action") or ""
        direction = "LONG" if _is_long(act, zt) else "SHORT"
        dedup_key = f"{sym}|{zt}|{direction}"

        if ts is None:
            continue

        prev = recent_key_ts.get(dedup_key)
        if prev is not None and (ts - prev).total_seconds() < DEDUP_WINDOW_SECONDS:
            duplicate_ids.add(doc["_id"])
        else:
            recent_key_ts[dedup_key] = ts

    # ── Agrupar por (symbol, date) para carregar preços em lote ───────────
    from collections import defaultdict
    by_sym_date: Dict[Tuple, List] = defaultdict(list)
    for doc in candidates:
        if doc["_id"] in duplicate_ids:
            continue
        ts  = _parse_ts(doc.get("ts"))
        sym = (doc.get("symbol") or "MNQ").upper()
        if ts is None:
            continue
        key = (sym, ts.date())
        by_sym_date[key].append(doc)

    # Carregar preços para cada (symbol, date)
    prices_cache: Dict[Tuple, List] = {}
    for (sym, date), docs in by_sym_date.items():
        day_start = datetime(date.year, date.month, date.day, tzinfo=timezone.utc)
        day_end   = day_start + timedelta(days=2)
        raw = await snap_col.find(
            {"symbol": sym, "recorded_at": {"$gte": day_start, "$lt": day_end},
             "last_price": {"$gt": 0}},
            {"recorded_at": 1, "last_price": 1},
        ).sort("recorded_at", 1).to_list(None)
        parsed = []
        for r in raw:
            t = _parse_ts(r.get("recorded_at"))
            p = r.get("last_price")
            if t and p and p > 0:
                parsed.append((t, float(p)))
        prices_cache[(sym, date)] = parsed

    # ── Marcar duplicados no MongoDB ───────────────────────────────────────
    dup_update = {
        "hyp_computed":      True,
        "hyp_computed_at":   now,
        "hyp_outcome":       "DUPLICATE",
        "hyp_pnl_pts":       None,
        "hyp_exit_price":    None,
        "hyp_exit_at":       None,
        "hyp_entry_reached": None,
    }
    duplicates_written = 0
    for doc in candidates:
        if doc["_id"] in duplicate_ids:
            try:
                await sig_col.update_one({"_id": doc["_id"]}, {"$set": dup_update})
                duplicates_written += 1
            except Exception as e:
                logger.warning("hyp_outcomes: erro ao marcar DUPLICATE %s: %s", doc["_id"], e)

    # ── Processar candidatos não-duplicados ────────────────────────────────
    processed = skipped = errors = 0

    for doc in candidates:
        if doc["_id"] in duplicate_ids:
            continue
        try:
            ts  = _parse_ts(doc.get("ts"))
            sym = (doc.get("symbol") or "MNQ").upper()
            if ts is None:
                skipped += 1
                continue

            all_prices   = prices_cache.get((sym, ts.date()), [])
            prices_after = [(t, p) for t, p in all_prices if t >= ts]

            outcome = compute_hyp_outcome(doc, prices_after)
            if outcome.get("hyp_outcome") == "NO_DATA" and not prices_after:
                outcome["hyp_computed"] = True
                await sig_col.update_one({"_id": doc["_id"]}, {"$set": outcome})
                skipped += 1
                continue

            await sig_col.update_one(
                {"_id": doc["_id"]},
                {"$set": outcome},
            )
            processed += 1

        except Exception as e:
            logger.warning("hyp_outcomes: erro em doc %s: %s", doc.get("_id"), e)
            errors += 1

    logger.info(
        "hyp_outcomes: processed=%d skipped=%d errors=%d duplicates=%d",
        processed, skipped, errors, duplicates_written,
    )
    return {
        "processed":  processed,
        "skipped":    skipped,
        "errors":     errors,
        "duplicates": duplicates_written,
    }

"""
github_backup_service.py
━━━━━━━━━━━━━━━━━━━━━━━━
Backup automático periódico para GitHub (ventonorte21/Quantum_v2).

Dois tipos de backup:
  1. CÓDIGO  — ZIP do source via GitHub Contents API → code-backups/code-YYYY-MM-DD.zip
  2. DADOS   — export das collections Atlas (JSON.gz) via GitHub Contents API
               → pasta data-backups/YYYY-MM-DD/ no repositório

Requisito: secret GITHUB_TOKEN com scope "repo" no Replit.

━━━━━━━━━━━━━━━━━━━━━━━━
POLÍTICA DE RETENÇÃO E RESTORE
━━━━━━━━━━━━━━━━━━━━━━━━

Retenção:
  - RETENTION_DAYS (30 por omissão) — apenas documentos mais recentes que N dias
    são exportados para colecções volumosas (snapshots, trades, signal_log, pb_state_log).
  - Colecções de config/estado são exportadas na totalidade (sem filtro temporal).

Tamanho de ficheiro:
  - MAX_FILE_BYTES (20 MB comprimido) — se o export exceder este limite, é dividido
    em chunks CHUNK_DOCS documentos cada, com sufixo _part1, _part2, etc.
  - Limite conservador face ao overhead base64 da GitHub Contents API (~33%).

Prune de pastas antigas:
  - _prune_old_backups() apaga pastas data-backups/YYYY-MM-DD/ com mais de
    RETENTION_DAYS dias via GitHub Contents API (apaga ficheiro a ficheiro).

Drill de restore (semanal):
  - Procedimento: descarregar data-backups/YYYY-MM-DD/scalp_signal_log.json.gz
    e data-backups/YYYY-MM-DD/pb_state_log.json.gz do repositório GitHub,
    descomprimir, e importar para a instância local MongoDB (mongoimport ou
    motor.insert_many). Validar contagem de documentos antes/após.
  - Critério de aceite: restore de 1 dia completa sem erros; contagem pós-restore
    ≥ contagem no ficheiro exportado.
  - Frequência recomendada: semanal (toda segunda-feira pré-abertura de mercado).
"""

from __future__ import annotations

import asyncio
import base64
import gzip
import json
import logging
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import httpx

logger = logging.getLogger("github_backup")

# ─── Configurações ────────────────────────────────────────────────────────────
GITHUB_REPO   = "ventonorte21/Quantum_v2"
GITHUB_API    = "https://api.github.com"
DATA_BRANCH   = "main"
DATA_PREFIX   = "data-backups"

DEFAULT_INTERVAL_HOURS = 12

# Retenção: exportar apenas documentos mais recentes que N dias (colecções volumosas)
RETENTION_DAYS = 30

# Limite de tamanho por ficheiro comprimido (20 MB — margem face ao overhead base64 da API)
MAX_FILE_BYTES = 20 * 1024 * 1024

# Número de documentos por chunk quando MAX_FILE_BYTES é excedido
CHUNK_DOCS = 5_000

# Campo de data por colecção — usado para filtro de retenção
# Colecções não listadas aqui são exportadas na totalidade (config/estado)
COLLECTION_DATE_FIELD: Dict[str, str] = {
    "scalp_trades":     "created_at",
    "scalp_snapshots":  "recorded_at",
    "scalp_signal_log": "ts",
    "pb_state_log":     "ts",
    "scalp_history":    "ts",
}

# Collections a exportar (pares: nome_collection → nome_arquivo)
COLLECTIONS_TO_EXPORT = [
    ("scalp_config",       "scalp_config"),
    ("scalp_trades",       "scalp_trades"),
    ("scalp_trader_state", "scalp_trader_state"),
    ("scalp_snapshots",    "scalp_snapshots"),
    ("scalp_history",      "scalp_history"),
    ("scalp_fills",        "scalp_fills"),
    ("positions",          "positions"),
    ("pb_state_log",       "pb_state_log"),
    ("scalp_signal_log",   "scalp_signal_log"),
]

WORKSPACE_ROOT = Path(__file__).parent.parent.parent

# ─── Estado global ────────────────────────────────────────────────────────────
_backup_task:   Optional[asyncio.Task] = None
_last_run:      Optional[str] = None
_last_status:   Optional[str] = None
_last_error:    Optional[str] = None
_is_running:    bool = False


# ══════════════════════════════════════════════════════════════════════════════
# GitHub API helpers
# ══════════════════════════════════════════════════════════════════════════════

def _get_token() -> str:
    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        raise RuntimeError(
            "GITHUB_TOKEN não configurado. "
            "Adicione o secret no painel de Secrets do Replit."
        )
    return token


def _gh_headers(token: str) -> Dict[str, str]:
    return {
        "Authorization": f"token {token}",
        "Accept":        "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }


async def _gh_get_file_sha(
    client: httpx.AsyncClient, token: str, path: str
) -> Optional[str]:
    """Retorna o SHA do ficheiro se existir (necessário para update via Contents API)."""
    url = f"{GITHUB_API}/repos/{GITHUB_REPO}/contents/{path}"
    r = await client.get(url, headers=_gh_headers(token))
    if r.status_code == 200:
        return r.json().get("sha")
    return None


async def _gh_put_file(
    client: httpx.AsyncClient,
    token: str,
    path: str,
    content_bytes: bytes,
    message: str,
) -> bool:
    """Cria ou actualiza um ficheiro no repositório via Contents API."""
    sha = await _gh_get_file_sha(client, token, path)
    url = f"{GITHUB_API}/repos/{GITHUB_REPO}/contents/{path}"
    body: Dict[str, Any] = {
        "message": message,
        "content": base64.b64encode(content_bytes).decode(),
        "branch":  DATA_BRANCH,
    }
    if sha:
        body["sha"] = sha
    r = await client.put(url, headers=_gh_headers(token), json=body, timeout=60)
    if r.status_code in (200, 201):
        logger.info("GitHub push OK: %s", path)
        return True
    logger.error("GitHub push FAIL %s: %s %s", path, r.status_code, r.text[:200])
    return False


async def _gh_delete_file(
    client: httpx.AsyncClient,
    token: str,
    path: str,
    message: str,
) -> bool:
    """Apaga um ficheiro do repositório via Contents API (necessário para prune)."""
    sha = await _gh_get_file_sha(client, token, path)
    if not sha:
        return True
    url = f"{GITHUB_API}/repos/{GITHUB_REPO}/contents/{path}"
    body = {"message": message, "sha": sha, "branch": DATA_BRANCH}
    r = await client.delete(url, headers=_gh_headers(token), json=body, timeout=30)
    if r.status_code in (200, 204):
        logger.info("GitHub delete OK: %s", path)
        return True
    logger.warning("GitHub delete FAIL %s: %s", path, r.status_code)
    return False


# ══════════════════════════════════════════════════════════════════════════════
# Atlas export com retenção e chunking
# ══════════════════════════════════════════════════════════════════════════════

async def _export_collection(
    database,
    collection_name: str,
    min_date: Optional[datetime] = None,
) -> List[Dict]:
    """
    Exporta uma collection MongoDB para lista de dicts (sem _id).

    Se min_date for fornecido e a colecção tiver campo de data definido em
    COLLECTION_DATE_FIELD, aplica filtro temporal para respeitar RETENTION_DAYS.
    """
    col = getattr(database, collection_name, None)
    if col is None:
        return []

    query: Dict = {}
    date_field = COLLECTION_DATE_FIELD.get(collection_name)
    if min_date and date_field:
        query[date_field] = {"$gte": min_date}

    cursor = col.find(query, {"_id": 0})
    docs = []
    async for doc in cursor:
        for k, v in list(doc.items()):
            if hasattr(v, "isoformat"):
                doc[k] = v.isoformat()
        docs.append(doc)
    return docs


def _compress_docs(docs: List[Dict]) -> bytes:
    """Serializa e comprime lista de documentos."""
    payload = json.dumps(docs, ensure_ascii=False, default=str).encode()
    return gzip.compress(payload, compresslevel=6)


async def _export_all(database) -> Dict[str, List[Tuple[bytes, int, str]]]:
    """
    Exporta todas as collections configuradas com retenção e chunking.

    Retorna dict: {file_name → [(conteúdo_gzip, n_docs, sufixo_chunk)]}
    Sufixo vazio → ficheiro único; "_part1", "_part2" → chunks.
    """
    min_date = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
    results: Dict[str, List[Tuple[bytes, int, str]]] = {}

    for col_name, file_name in COLLECTIONS_TO_EXPORT:
        try:
            docs = await _export_collection(database, col_name, min_date=min_date)
            compressed = _compress_docs(docs)
            size_mb = len(compressed) / 1024 / 1024

            if len(compressed) <= MAX_FILE_BYTES:
                results[file_name] = [(compressed, len(docs), "")]
                logger.info(
                    "Export %s: %d docs → %.1f MB gzip",
                    col_name, len(docs), size_mb,
                )
            else:
                # Dividir em chunks de CHUNK_DOCS documentos
                chunks = []
                for i in range(0, len(docs), CHUNK_DOCS):
                    chunk_docs = docs[i: i + CHUNK_DOCS]
                    chunk_gz   = _compress_docs(chunk_docs)
                    part_num   = len(chunks) + 1
                    chunks.append((chunk_gz, len(chunk_docs), f"_part{part_num}"))
                results[file_name] = chunks
                logger.info(
                    "Export %s: %d docs → %.1f MB → %d chunks",
                    col_name, len(docs), size_mb, len(chunks),
                )
        except Exception as exc:
            logger.warning("Export %s falhou: %s", col_name, exc)

    return results


# ══════════════════════════════════════════════════════════════════════════════
# Prune de backups antigos
# ══════════════════════════════════════════════════════════════════════════════

async def _prune_old_backups(
    client: httpx.AsyncClient, token: str
) -> int:
    """
    Apaga pastas data-backups/YYYY-MM-DD/ com mais de RETENTION_DAYS dias.
    Retorna o número de pastas removidas.
    """
    cutoff = datetime.now(timezone.utc) - timedelta(days=RETENTION_DAYS)
    url = f"{GITHUB_API}/repos/{GITHUB_REPO}/contents/{DATA_PREFIX}"
    r = await client.get(url, headers=_gh_headers(token), params={"ref": DATA_BRANCH})
    if r.status_code != 200:
        logger.warning("Prune: não foi possível listar %s (status=%s)", DATA_PREFIX, r.status_code)
        return 0

    pruned = 0
    for entry in r.json():
        if entry.get("type") != "dir":
            continue
        name = entry.get("name", "")
        try:
            folder_date = datetime.strptime(name, "%Y-%m-%d").replace(tzinfo=timezone.utc)
        except ValueError:
            continue
        if folder_date >= cutoff:
            continue

        # Listar e apagar todos os ficheiros na pasta
        folder_url = f"{GITHUB_API}/repos/{GITHUB_REPO}/contents/{DATA_PREFIX}/{name}"
        fr = await client.get(folder_url, headers=_gh_headers(token), params={"ref": DATA_BRANCH})
        if fr.status_code != 200:
            continue
        for file_entry in fr.json():
            if file_entry.get("type") == "file":
                file_path = file_entry["path"]
                await _gh_delete_file(
                    client, token, file_path,
                    f"prune(data): remove {file_path} (>{RETENTION_DAYS}d)",
                )
        pruned += 1
        logger.info("Prune: pasta %s/%s removida", DATA_PREFIX, name)

    return pruned


# ══════════════════════════════════════════════════════════════════════════════
# Code backup
# ══════════════════════════════════════════════════════════════════════════════

async def _push_code_via_api(
    client: httpx.AsyncClient, token: str, date_str: str
) -> Tuple[bool, str]:
    import io, zipfile

    INCLUDE_DIRS  = ["backend", "frontend/src", "frontend/public"]
    INCLUDE_EXTS  = {".py", ".js", ".jsx", ".ts", ".tsx", ".json", ".md",
                     ".yml", ".yaml", ".sh", ".txt", ".css", ".html"}
    EXCLUDE_NAMES = {"__pycache__", "node_modules", ".git", ".pythonlibs",
                     "build", "dist", ".mypy_cache", ".pytest_cache"}

    buf = io.BytesIO()
    n_files = 0
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for include_dir in INCLUDE_DIRS:
            src = WORKSPACE_ROOT / include_dir
            if not src.exists():
                continue
            for p in src.rglob("*"):
                if any(ex in p.parts for ex in EXCLUDE_NAMES):
                    continue
                if p.is_file() and p.suffix in INCLUDE_EXTS:
                    arcname = str(p.relative_to(WORKSPACE_ROOT))
                    zf.write(p, arcname)
                    n_files += 1

        for root_file in ["replit.md", "start_backend.sh", "start_production.sh",
                          "pyproject.toml", "requirements.txt"]:
            fp = WORKSPACE_ROOT / root_file
            if fp.exists():
                zf.write(fp, root_file)
                n_files += 1

    zip_bytes = buf.getvalue()
    logger.info("Code ZIP: %d ficheiros → %.1f KB", n_files, len(zip_bytes) / 1024)

    path = f"code-backups/code-{date_str}.zip"
    msg  = f"backup(code): {date_str} ({n_files} ficheiros)"
    ok = await _gh_put_file(client, token, path, zip_bytes, msg)
    if ok:
        return True, "OK"
    return False, f"upload falhou para {path}"


# ══════════════════════════════════════════════════════════════════════════════
# Backup principal
# ══════════════════════════════════════════════════════════════════════════════

async def run_backup(database, include_code: bool = True) -> Dict[str, Any]:
    """
    Executa o backup completo:
      1. Exporta collections Atlas → JSON.gz → GitHub Contents API
         (com retenção RETENTION_DAYS e chunking MAX_FILE_BYTES)
      2. Apaga pastas de backup com mais de RETENTION_DAYS dias (prune)
      3. (Opcional) ZIP do código → branch main

    Retorna sumário do backup.
    """
    global _last_run, _last_status, _last_error, _is_running

    if _is_running:
        return {"status": "already_running", "message": "Backup já em execução"}

    _is_running = True
    token = _get_token()
    now = datetime.now(timezone.utc)
    date_str = now.strftime("%Y-%m-%d")
    ts_str   = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    summary: Dict[str, Any] = {
        "started_at":    ts_str,
        "date":          date_str,
        "repo":          GITHUB_REPO,
        "retention_days": RETENTION_DAYS,
        "data_pushed":   {},
        "pruned_folders": 0,
        "code_pushed":   False,
        "errors":        [],
    }

    try:
        logger.info("Backup iniciado: exportando Atlas → GitHub (%s, retenção=%dd)", date_str, RETENTION_DAYS)
        exports = await _export_all(database)

        async with httpx.AsyncClient(timeout=120) as client:
            for file_name, chunks in exports.items():
                summary["data_pushed"][file_name] = {"chunks": [], "total_docs": 0, "ok": True}

                for content_gz, n_docs, suffix in chunks:
                    fname = f"{file_name}{suffix}.json.gz"
                    path  = f"{DATA_PREFIX}/{date_str}/{fname}"
                    msg   = f"backup(data): {fname} {date_str} ({n_docs} docs)"
                    ok    = await _gh_put_file(client, token, path, content_gz, msg)
                    summary["data_pushed"][file_name]["chunks"].append({
                        "file":  fname,
                        "ok":    ok,
                        "docs":  n_docs,
                        "bytes": len(content_gz),
                        "path":  path,
                    })
                    summary["data_pushed"][file_name]["total_docs"] += n_docs
                    if not ok:
                        summary["data_pushed"][file_name]["ok"] = False
                        summary["errors"].append(f"data push falhou: {fname}")

            # ── Manifesto ──────────────────────────────────────────────────
            manifest = {
                "backup_at":    ts_str,
                "repo":         GITHUB_REPO,
                "retention_days": RETENTION_DAYS,
                "collections":  {
                    name: {"docs": info["total_docs"], "ok": info["ok"]}
                    for name, info in summary["data_pushed"].items()
                },
            }
            manifest_bytes = json.dumps(manifest, indent=2).encode()
            await _gh_put_file(
                client, token,
                f"{DATA_PREFIX}/{date_str}/manifest.json",
                manifest_bytes,
                f"backup(manifest): {date_str}",
            )

            # ── Prune de pastas antigas ─────────────────────────────────────
            try:
                pruned = await _prune_old_backups(client, token)
                summary["pruned_folders"] = pruned
            except Exception as pe:
                logger.warning("Prune erro (não crítico): %s", pe)

        # ── Código ──────────────────────────────────────────────────────────
        if include_code:
            async with httpx.AsyncClient(timeout=300) as code_client:
                code_ok, code_msg = await _push_code_via_api(code_client, token, date_str)
            summary["code_pushed"] = code_ok
            if not code_ok:
                summary["errors"].append(f"code zip push: {code_msg}")

        summary["finished_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        summary["status"] = "ok" if not summary["errors"] else "partial"
        _last_status = summary["status"]
        _last_error  = "; ".join(summary["errors"]) if summary["errors"] else None

    except Exception as exc:
        logger.exception("Backup erro crítico: %s", exc)
        summary["status"] = "error"
        summary["errors"].append(str(exc))
        _last_status = "error"
        _last_error  = str(exc)
    finally:
        _is_running = False
        _last_run   = ts_str

    logger.info(
        "Backup concluído: status=%s docs=%s pruned=%d code=%s erros=%d",
        summary["status"],
        {k: v["total_docs"] for k, v in summary["data_pushed"].items()},
        summary.get("pruned_folders", 0),
        summary.get("code_pushed"),
        len(summary["errors"]),
    )
    return summary


# ══════════════════════════════════════════════════════════════════════════════
# Scheduler periódico
# ══════════════════════════════════════════════════════════════════════════════

async def _backup_loop(database, interval_hours: float):
    logger.info(
        "GitHubBackup scheduler iniciado (intervalo: %.1fh → %s)",
        interval_hours, GITHUB_REPO,
    )
    while True:
        try:
            logger.info("GitHubBackup: iniciando backup...")
            await run_backup(database, include_code=True)
        except Exception as exc:
            logger.error("GitHubBackup loop erro: %s", exc)
        await asyncio.sleep(interval_hours * 3600)


def start_backup_scheduler(database, interval_hours: float = DEFAULT_INTERVAL_HOURS):
    global _backup_task

    is_production = os.environ.get("REPLIT_DEPLOYMENT") == "1"
    if not is_production:
        logger.info(
            "GitHubBackup: ambiente de desenvolvimento detectado — "
            "scheduler desactivado (backups correm apenas em produção)."
        )
        return False

    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        logger.warning(
            "GitHubBackup: GITHUB_TOKEN não configurado — scheduler NÃO iniciado. "
            "Adicione o secret GITHUB_TOKEN para activar backups automáticos."
        )
        return False

    if _backup_task and not _backup_task.done():
        logger.info("GitHubBackup scheduler já em execução.")
        return True

    _backup_task = asyncio.create_task(
        _backup_loop(database, interval_hours),
        name="github_backup_loop",
    )
    logger.info(
        "GitHubBackup scheduler iniciado (intervalo=%.1fh, repo=%s, retenção=%dd)",
        interval_hours, GITHUB_REPO, RETENTION_DAYS,
    )
    return True


def stop_backup_scheduler():
    global _backup_task
    if _backup_task and not _backup_task.done():
        _backup_task.cancel()
        logger.info("GitHubBackup scheduler cancelado.")


def get_backup_status() -> Dict[str, Any]:
    token_ok          = bool(os.environ.get("GITHUB_TOKEN", ""))
    is_production     = os.environ.get("REPLIT_DEPLOYMENT") == "1"
    scheduler_running = bool(_backup_task and not _backup_task.done())
    return {
        "scheduler_running":  scheduler_running,
        "token_configured":   token_ok,
        "is_production":      is_production,
        "is_running":         _is_running,
        "last_run":           _last_run,
        "last_status":        _last_status,
        "last_error":         _last_error,
        "repo":               GITHUB_REPO,
        "interval_hours":     DEFAULT_INTERVAL_HOURS,
        "retention_days":     RETENTION_DAYS,
        "max_file_mb":        MAX_FILE_BYTES / 1024 / 1024,
        "data_branch":        DATA_BRANCH,
        "data_prefix":        DATA_PREFIX,
    }

"""
scalp_hyp_outcomes.py
─────────────────────
Motor de outcomes hipotéticos para sinais bloqueados no scalp_signal_log.

Para cada sinal bloqueado com preços S3 disponíveis (entry/SL/TP), escaneia
scalp_snapshots.last_price no período após o bloco e determina o outcome real
que teria ocorrido:
  - TP_HIT    : preço atingiu take-profit antes do SL e antes do EOD
  - SL_HIT    : preço atingiu stop-loss antes do TP e antes do EOD
  - EOD       : sessão terminou sem TP/SL — usa último preço disponível (MTM)
  - NO_DATA   : sem snapshots suficientes para determinar outcome

Outputs persistidos directamente no documento signal_log via $set:
  hyp_outcome      : "TP_HIT" | "SL_HIT" | "EOD" | "NO_DATA"
  hyp_pnl_pts      : float — PnL em pontos do índice (positivo = ganho)
  hyp_exit_price   : float — preço de saída usado
  hyp_exit_at      : datetime — timestamp da saída
  hyp_computed_at  : datetime — quando o cálculo foi feito
  hyp_computed     : True
"""
from __future__ import annotations

import logging
from datetime   import datetime, timezone, timedelta
from typing     import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# ── Constantes ────────────────────────────────────────────────────────────────

TICK_SIZE_PTS   = 0.25          # 1 tick = 0.25 pontos (MNQ e MES)
EOD_GAP_HOURS   = 3.0           # gap de preços > 3h = fim de sessão
DEFAULT_TICKS_SL = {"MNQ": 6,  "MES": 4}
DEFAULT_TICKS_TP = {"MNQ": 10, "MES": 8}

# ── Helpers ───────────────────────────────────────────────────────────────────

def _parse_ts(v) -> Optional[datetime]:
    if isinstance(v, datetime):
        return v.replace(tzinfo=timezone.utc) if v.tzinfo is None else v
    try:
        return datetime.fromisoformat(str(v).replace("Z", "+00:00"))
    except Exception:
        return None


def _is_long(action: Optional[str], zone_type: Optional[str]) -> bool:
    """Determina direcção: BUY=long, SELL=short. Deriva de zone_type se action for None."""
    if action:
        return action.upper() in ("BUY", "LONG")
    zt = (zone_type or "").upper()
    return zt.endswith("_BUY") or "BUY" in zt


def _derive_sl_tp(
    entry: float,
    is_long: bool,
    symbol: str,
    param_snapshot: Dict,
) -> Tuple[float, float]:
    """
    Reconstrói SL e TP a partir de entry + config de ticks.
    Usado para sinais antigos que não têm s3_sl_price/s3_tp_price armazenados.
    """
    sym = (symbol or "MNQ").upper()
    snap = param_snapshot or {}

    sl_key = f"sl_ticks_{sym.lower()}"
    tp_key = f"tp_ticks_{sym.lower()}"
    sl_ticks = float(snap.get(sl_key) or DEFAULT_TICKS_SL.get(sym, 6))
    tp_ticks = float(snap.get(tp_key) or DEFAULT_TICKS_TP.get(sym, 10))

    sl_pts = sl_ticks * TICK_SIZE_PTS
    tp_pts = tp_ticks * TICK_SIZE_PTS

    if is_long:
        return entry - sl_pts, entry + tp_pts
    else:
        return entry + sl_pts, entry - tp_pts


# ── Engine principal ──────────────────────────────────────────────────────────

def compute_hyp_outcome(
    signal_doc: Dict[str, Any],
    prices: List[Tuple[datetime, float]],
) -> Dict[str, Any]:
    """
    Calcula o outcome hipotético de um sinal bloqueado.

    Args:
        signal_doc : documento do scalp_signal_log
        prices     : lista ordenada de (timestamp, last_price) do mesmo symbol
                     a partir do momento do bloco (já filtrada externamente)

    Returns:
        dict com hyp_outcome, hyp_pnl_pts, hyp_exit_price, hyp_exit_at,
        hyp_computed_at, hyp_computed=True
    """
    now = datetime.now(timezone.utc)
    result_base = {
        "hyp_computed":    True,
        "hyp_computed_at": now,
        "hyp_outcome":     "NO_DATA",
        "hyp_pnl_pts":     None,
        "hyp_exit_price":  None,
        "hyp_exit_at":     None,
    }

    if not prices:
        return result_base

    # ── Obter entry/SL/TP ──────────────────────────────────────────────────
    entry = (
        signal_doc.get("s3_entry_price")
        or signal_doc.get("zone_level")
    )
    if not entry or float(entry) <= 0:
        return result_base

    entry   = float(entry)
    sl_raw  = signal_doc.get("s3_sl_price")
    tp_raw  = signal_doc.get("s3_tp_price")
    action  = signal_doc.get("s3_action")
    sym     = (signal_doc.get("symbol") or "MNQ").upper()
    zt      = signal_doc.get("zone_type") or ""
    long    = _is_long(action, zt)

    if sl_raw and tp_raw:
        sl = float(sl_raw)
        tp = float(tp_raw)
    else:
        # Sinal antigo sem s3_sl/tp: deriva de ticks
        snap = signal_doc.get("param_snapshot") or {}
        sl, tp = _derive_sl_tp(entry, long, sym, snap)

    # Validação básica de consistência
    if long:
        if not (sl < entry < tp):
            return result_base
    else:
        if not (tp < entry < sl):
            return result_base

    # ── Scan de preços ─────────────────────────────────────────────────────
    last_price:    Optional[float]    = None
    last_ts:       Optional[datetime] = None
    prev_ts:       Optional[datetime] = None

    for p_ts, price in prices:
        # Detectar gap de EOD (> EOD_GAP_HOURS sem snapshot)
        if prev_ts is not None:
            gap_h = (p_ts - prev_ts).total_seconds() / 3600.0
            if gap_h >= EOD_GAP_HOURS:
                # Sessão anterior terminou — usa último preço antes do gap
                break

        prev_ts    = p_ts
        last_price = price
        last_ts    = p_ts

        if long:
            if price >= tp:
                pnl = round(tp - entry, 4)
                return {**result_base, "hyp_outcome": "TP_HIT",
                        "hyp_pnl_pts": pnl, "hyp_exit_price": tp, "hyp_exit_at": p_ts}
            if price <= sl:
                pnl = round(sl - entry, 4)
                return {**result_base, "hyp_outcome": "SL_HIT",
                        "hyp_pnl_pts": pnl, "hyp_exit_price": sl, "hyp_exit_at": p_ts}
        else:
            if price <= tp:
                pnl = round(entry - tp, 4)
                return {**result_base, "hyp_outcome": "TP_HIT",
                        "hyp_pnl_pts": pnl, "hyp_exit_price": tp, "hyp_exit_at": p_ts}
            if price >= sl:
                pnl = round(entry - sl, 4)
                return {**result_base, "hyp_outcome": "SL_HIT",
                        "hyp_pnl_pts": pnl, "hyp_exit_price": sl, "hyp_exit_at": p_ts}

    # ── EOD: nem TP nem SL atingidos — mark-to-market no último preço ─────
    if last_price is not None and last_ts is not None:
        if long:
            pnl = round(last_price - entry, 4)
        else:
            pnl = round(entry - last_price, 4)
        return {**result_base, "hyp_outcome": "EOD",
                "hyp_pnl_pts": pnl, "hyp_exit_price": last_price, "hyp_exit_at": last_ts}

    return result_base


# ── Batch compute ─────────────────────────────────────────────────────────────

async def compute_all_pending(database, days_back: int = 90) -> Dict[str, int]:
    """
    Processa todos os sinais bloqueados no signal_log que ainda não têm
    hyp_computed=True e têm entry/SL/TP disponíveis.

    Carrega os snapshots de preços uma vez por símbolo e data, depois
    aplica compute_hyp_outcome a cada sinal em memória.

    Returns:
        {"processed": N, "skipped": M, "errors": K}
    """
    sig_col  = database["scalp_signal_log"]
    snap_col = database["scalp_snapshots"]
    now      = datetime.now(timezone.utc)
    date_min = now - timedelta(days=days_back)

    # Sinais candidatos: bloqueados, com zone_type, sem hyp_computed
    query = {
        "ts":          {"$gte": date_min},
        "gate_outcome": {"$nin": ["EXECUTED", "FA_SHADOW"]},
        "zone_type":   {"$nin": [None, "", "None", "?"]},
        "hyp_computed": {"$ne": True},
        "$or": [
            {"s3_entry_price": {"$ne": None}},
            {"zone_level":     {"$ne": None}},
        ],
    }

    candidates = await sig_col.find(query, {
        "_id": 1, "ts": 1, "symbol": 1, "zone_type": 1,
        "s3_action": 1, "s3_entry_price": 1, "s3_sl_price": 1, "s3_tp_price": 1,
        "zone_level": 1, "param_snapshot": 1,
    }).sort("ts", 1).to_list(None)

    if not candidates:
        return {"processed": 0, "skipped": 0, "errors": 0}

    # ── Agrupar por (symbol, date) para carregar preços em lote ───────────
    from collections import defaultdict
    by_sym_date: Dict[Tuple, List] = defaultdict(list)
    for doc in candidates:
        ts  = _parse_ts(doc.get("ts"))
        sym = (doc.get("symbol") or "MNQ").upper()
        if ts is None:
            continue
        key = (sym, ts.date())
        by_sym_date[key].append(doc)

    # Carregar preços para cada (symbol, date) — 90 dias max de janela
    prices_cache: Dict[Tuple, List] = {}
    for (sym, date), docs in by_sym_date.items():
        day_start = datetime(date.year, date.month, date.day, tzinfo=timezone.utc)
        day_end   = day_start + timedelta(days=2)   # inclui overnight seguinte
        raw = await snap_col.find(
            {"symbol": sym, "recorded_at": {"$gte": day_start, "$lt": day_end},
             "last_price": {"$gt": 0}},
            {"recorded_at": 1, "last_price": 1},
        ).sort("recorded_at", 1).to_list(None)
        parsed = []
        for r in raw:
            t = _parse_ts(r.get("recorded_at"))
            p = r.get("last_price")
            if t and p and p > 0:
                parsed.append((t, float(p)))
        prices_cache[(sym, date)] = parsed

    # ── Processar cada candidato ───────────────────────────────────────────
    processed = skipped = errors = 0

    for doc in candidates:
        try:
            ts  = _parse_ts(doc.get("ts"))
            sym = (doc.get("symbol") or "MNQ").upper()
            if ts is None:
                skipped += 1
                continue

            all_prices = prices_cache.get((sym, ts.date()), [])
            # Filtrar apenas preços após o momento do bloco
            prices_after = [(t, p) for t, p in all_prices if t >= ts]

            outcome = compute_hyp_outcome(doc, prices_after)
            if outcome.get("hyp_outcome") == "NO_DATA" and not prices_after:
                # Sem snapshots disponíveis para este símbolo/data — marca como
                # computado para não re-processar indefinidamente (sistema estava
                # offline ou fim-de-semana), mas conta como skipped, não processed.
                outcome["hyp_computed"] = True
                await sig_col.update_one({"_id": doc["_id"]}, {"$set": outcome})
                skipped += 1
                continue

            await sig_col.update_one(
                {"_id": doc["_id"]},
                {"$set": outcome},
            )
            processed += 1

        except Exception as e:
            logger.warning("hyp_outcomes: erro em doc %s: %s", doc.get("_id"), e)
            errors += 1

    logger.info(
        "hyp_outcomes: processed=%d skipped=%d errors=%d",
        processed, skipped, errors,
    )
    return {"processed": processed, "skipped": skipped, "errors": errors}
